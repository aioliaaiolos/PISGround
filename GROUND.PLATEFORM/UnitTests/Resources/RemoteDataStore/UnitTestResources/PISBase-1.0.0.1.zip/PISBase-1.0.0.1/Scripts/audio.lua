--=============================================================================================
-- Description : audio functions
--=============================================================================================
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 28/01/2011, A. Lafont de Sentenac
-- Corrections suite � tests sur MI09
--
-- 04/02/2011, A. Lafont de Sentenac
-- Correction du groupe dans mStopAudio
--
-- 16/03/2001, A. Lafont de Sentenac
-- Correction CR ALPHA00221715: Contenu media : Probl�me lors de la mise � jour de messages pr�d�finis audio (chemin du fichier audio incorrect)
--
--============================================================================================

gSoundDir = "";

function mInitAudio(pMatrix )
	util.trace( "mInitAudio", util.L1 );
	playerwav.set_dmatrix(pMatrix);  
end;
	
function mUpdateAudio(pEvent, pGroup, pStation, pContext)
	util.trace( "mUpdateAudio "..pEvent.." - "..pGroup, util.L1 );
	local missionCode = pContext["=MISSION_CODE="];
	local station = "*";
	if pStation ~= nil then
		station = pContext[pStation];
		util.trace( "mUpdateAudio for station "..station, util.L3 );
	end

	-- traitement update audio
	mPlayAudioMessages(mGetEventMessage(pEvent, pGroup, gAudioGroupType, missionCode, station, gDefaultStationAudio, pContext));
end;
	
function mPlayAudioMessages(pMessageInfoList)
	util.trace( "mPlayAudioMessages", util.L3 );
	local lAnnouncement = nil;
	local lPriority = nil;
	local lGroup = nil;
	for _,lMessageInfo in ipairs(pMessageInfoList) do
		local lAudioFileName = "";
		lGroup = lMessageInfo.group;
		for _,lAudioFileName in ipairs(lMessageInfo.messageList) do
			if lAudioFileName == gSilenceVariable then
				lAnnouncement = appendSilence( lAnnouncement, lMessageInfo.duration);
			else
				lAnnouncement = appendWaveFile( lAnnouncement, gSoundDir .. lAudioFileName, tonumber(lMessageInfo.duration) );
			end;
			if lPriority == nil then
				lPriority = lMessageInfo.priority;
			end;
		end;
	end;
	
	if lGroup ~= nil then
		mPlayAudio(lGroup, lAnnouncement, lPriority)
	end;
end;

function mPlayAudio(pGroup, pAnnouncement, pPriority)  
	util.trace( "mPlayAudio (announcement "..tostring(pAnnouncement)..", priority "..tostring(pPriority)..", group "..tostring(pGroup)..")", util.L1 );
	playerwav.play( pPriority, pGroup, pAnnouncement, tag.MISSION_MESSAGE );
end;

function mStopAudio( pPriotity, pGroup )
	util.trace( "mStopAudio", util.L1 );
	mPlayAudio( pGroup, playerwav.silence(100), pPriotity );
end;

-- opens and appends a file wave to an existing wave object and returns it.
-- creates the wave object if it does not exists
function appendWaveFile ( pWaveObject, pWaveFile, pDuration )
	local newWaveObject = openWaveFile( pWaveFile );
	local lWaveDuration = playerwav.get_duration(newWaveObject);
	if (lWaveDuration < pDuration) then
		newWaveObject = appendSilence(newWaveObject, (pDuration-lWaveDuration));
	end;
	
	if ( pWaveObject ~= nil ) then
		newWaveObject = playerwav.concat( pWaveObject, newWaveObject );
	end;
	return newWaveObject;
end;

function appendSilence( pWaveObject, pDuration)
	local newWaveObject = nil;
	if pWaveObject == nil then
		newWaveObject = playerwav.silence(pDuration);
	else
		newWaveObject = playerwav.concat( pWaveObject, playerwav.silence(pDuration*1000) );
	end;
	return newWaveObject;
end;

-- opens a wave file and returns the correspondign wave object.
-- logs an error if the file does not exist
function openWaveFile( pWaveFile )
	local sound = playerwav.open( pWaveFile );
	if ( sound == nil ) then
		-- wave file not found
		util.trace( "Wave file not found: " .. pWaveFile, util.LE );
	else
		--playerwav.close( sound );
	end;
	return sound;
end;