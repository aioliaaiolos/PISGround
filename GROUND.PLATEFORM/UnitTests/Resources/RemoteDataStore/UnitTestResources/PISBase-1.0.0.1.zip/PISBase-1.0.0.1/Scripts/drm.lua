--=============================================================================================
-- Description : DRM display functions
--=============================================================================================
--
-- 14/02/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00217588: Contenu M�dia : Gestion des PLD
--
-- 18/02/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00217588: Contenu M�dia : Gestion des PLD
--
-- 11/04/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00226603: Contenu M�dia : Certains appels � playerPld sont incorrect
--
--=============================================================================================

gCurrentDisplayDate = true;
gAlternate100TTaskList = {};
g100tTimerList = {};

-- DRM initialisation function
function mInitDRM( pListStation )
	util.trace( "mInitDRM", util.L1 );
	-- Init DRM player
	playerPld.set_station_code_list(pListStation);
	mClearDrmDisplays(const_drm.GROUP_ALL);
end;

function mUpdateDrmDisplays(pGroup, pBlinkingStation, pLightOnStations, pPriority)
	util.trace( "mUpdateDRMDisplays", util.L1 );
	local context = mBuildContext();
	local drmPageId = playerPld.create_page_from_template(const_drm.TEMPLATE);
	local lightOnStationsStr = "";
	for idx,val in ipairs(pLightOnStations) do
		if idx > 1 then
			lightOnStationsStr = lightOnStationsStr .. ";";
		end;
		lightOnStationsStr = lightOnStationsStr .. mReplaceVariables(val, gDefaultStationName, context);
	end;
	local blinkingStationStr = "";
	for idx,val in ipairs(pBlinkingStation) do
		if idx > 1 then
			blinkingStationStr = blinkingStationStr .. ";";
		end;
		blinkingStationStr = blinkingStationStr .. mReplaceVariables(val, gDefaultStationName, context);
	end;
	playerPld.set_status_specified_stations(drmPageId, lightOnStationsStr, playerPld.TARGET_STATIONS); --TARGET_STATIONS=still
	playerPld.set_status_specified_stations(drmPageId, blinkingStationStr, playerPld.SERVICED_STATIONS); --SERVICED_STATIONS=blink
	playerPld.play(pGroup, drmPageId);
end;

function mClearDrmDisplays(pGroup, pPriority)
	local drmPageId = playerPld.create_page_from_template(const_drm.TEMPLATE);
	playerPld.set_status_all_stations(drmPageId, playerPld.CLEARED_STATIONS);
	playerPld.play(pGroup, drmPageId);
end;

