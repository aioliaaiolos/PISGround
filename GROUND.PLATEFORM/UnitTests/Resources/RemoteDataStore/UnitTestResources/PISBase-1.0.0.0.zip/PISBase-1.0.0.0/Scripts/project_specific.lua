-- TO BE CONFIGURED BY PROJECT

function mInitProjectSpecific(pDisplayMatrix)
end;

function mStopProjectSpecific()
end;

function mInitProjectSpecificVariables()
end;

function mSetProjectSpecificEvents()
end;
