--=============================================================================================
-- Description : Resource access functions
--=============================================================================================
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 13/01/2011, A. Lafont de Sentenac
-- Gestion des fonctions depuis le XML
--
-- 13/01/2011, A. Lafont de Sentenac
-- Gestion des lignes et des infos
-- Gestion des conditions de fonction
--
-- 28/01/2011, A. Lafont de Sentenac
-- Corrections suite � tests sur MI09
--
-- 04/02/2011, A. Lafont de Sentenac
-- Renommage de ModeEvt en SpecialEvt
--
-- 15/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00217628: Contenu M�dia : Gestion de la priorit� lors des appels de fonctions
-- Impl�mentation CR ALPHA00217646: Contenu M�dia: fonctionnalit� pour r�cup�rer l'attribut "name" d'une station
--
-- 16/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00214812: Probl�me d'affichage sur les frontaux avec des zones vides
--
-- 11/04/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00226108: Contenu media : autoriser les valeurs vides lors de la r�solution des variables d'information
--
--=============================================================================================


function string:split(pat)
  pat = pat or '%s+'
  local st, g = 1, self:gmatch("()("..pat..")")
  local function getter(segs, seps, sep, cap1, ...)
    st = sep and seps + #sep
    return self:sub(segs, (seps or 0) - 1), cap1 or sep, ...
  end
  return function() if st then return getter(st, g()) end end
end

function mInitResources( )
	util.trace("mInitResources", util.L3);
	-- variables definitions :
	XML_TAG = {};
	XML_TAG.EVT="evt";
	XML_TAG.GROUP="group";
	XML_TAG.MISSION="mission";
	XML_TAG.STATION="station";
	XML_TAG.MSG="msg";
	XML_TAG.TEMPLATE="template";
	XML_TAG.LANG="lang";
	XML_TAG.CONDITION="condition";
	XML_TAG.VALUE="val";
	XML_TAG.DURATION="duration";
	XML_TAG.DATA="resource";
	XML_TAG.PREDEF="predef";
	XML_TAG.NAME="name";
	XML_TAG.TYPE="type";
	XML_TAG.FUNCTION="function";
	XML_TAG.PARAM = "param";
	XML_TAG.LITERAL = "literal";
	XML_TAG.LINE = "line";
	XML_TAG.INFO = "info";
	
	gDefaultStationName = "short_name";
	gDefaultStationAudio = "audio";
	gAudioGroupType = "AUD";
	g100tGroupType = "LED";
	g400tGroupType = "LCD";
	
	gDictionaryVariablesList = {};
	gStaticVariablesList = {};
	gDictionaryInfoVariablesList = {};
	gStaticInfoVariablesList = {};
	gSilenceVariable = "";
	gMissionEvtList = {};
	gStationEvtList = {};
	gSpecialEvtList = {};
	mInitVariables();
end;

function mBuildContext()
	util.trace("mBuildContext", util.L3);
	local context = {};
	for var, dicvar in pairs(gDictionaryVariablesList) do
		local lValue = dictionary.getvalue( gDictionary, dicvar );
		context[var] = lValue;
	end;

	for var, val in pairs(gStaticVariablesList) do
		context[var] = val;
	end;
	
	for var, dicvar in pairs(gDictionaryInfoVariablesList) do
		local lValue = dictionary.getvalue( gDictionary, dicvar[2] );
		context[var] = lValue;
	end;

	for var, val in pairs(gStaticInfoVariablesList) do
		context[var] = val[2];
	end;
	
	return context;
end;

-- info functions:
function mGetInfo( pTag, pType, pName, pContext )
	util.trace( "mGetInfo " .. pTag .. ", " .. pType .. " for "..pName, util.L3 );
	local nameToReturn = "";
	local attrNotFound = true;
	if pType == XML_TAG.NAME then
		nameToReturn = pName;
	else
		local node = xml:child_with_name(xml:root(), pTag, pName);
		if node ~= nil then
			local node_lang = xml:child_with_name(node, XML_TAG.LANG, pContext["=LANG="]);
			local nodes_names = xml:children(node_lang, XML_TAG.VALUE);

			for _,node_name in ipairs(nodes_names) do
				nameType = xml:attribute(node_name, XML_TAG.TYPE);
				if nameType == pType then
					name = xml:node_value(node_name);
					if name == nil then
						name = "";
					end;
					nameToReturn = name;
					attrNotFound = false;
					break;
				end;
			end;
			if attrNotFound then
				util.trace( "mGetInfo: attribute ".. pType .. " not found for " .. pTag .. " ".. pName, util.LW );
			end;
		else
			util.trace( "mGetInfo: no tag " .. pTag .. " which name attribute is equal to " .. pName, util.LW );
		end;
	end;
	return nameToReturn;
end;

-- groups retrieval functions:
function mGetEventGroups(pEvent, pType)
	util.trace( "mGetEventGroups: " .. tostring(pEvent) .. ", "..pType, util.L3 );
	local groups = {};
	node_evt = xml:child_with_name(xml:root(), XML_TAG.EVT, pEvent);
	if node_evt ~= nil then
		node_groups = xml:children_with_type(node_evt, XML_TAG.GROUP, pType);
		for _,node_grp in ipairs(node_groups) do
			table.insert(groups, xml:attribute(node_grp, XML_TAG.NAME));
		end;
	end;
	return groups;
end;

function mGetPredefGroups(pPredefId, pType)
	util.trace( "mGetPredefGroups: " .. tostring(pPredefId) .. ", "..pType, util.L3 );
	local groups = {};
	node_predef = xml:child_with_name(xml:root(), XML_TAG.PREDEF, pPredefId);
	if node_predef ~= nil then
		nodes_group = xml:children_with_type(node_predef, XML_TAG.GROUP, pType);
		for _,node_grp in ipairs(nodes_group) do
			table.insert(groups, xml:attribute(node_grp, XML_TAG.NAME));
		end;
	end;
	return groups;
end;

-- messages retrieval functions:
function mGetEventMessage(pEvent, pGroup, pGroupType, pMissionCode, pStation, pDefault, pContext)
	util.trace( "mGetEventMessage " .. tostring(pEvent) .. " " .. tostring(pGroup) .. " " .. tostring(pGroupType) .. " " .. tostring(pMissionCode) .. " " .. tostring(pStation) .. " ", util.L3 );
	node_evt = xml:child_with_name(xml:root(), XML_TAG.EVT, pEvent);
	node_grp = xml:child_with_name_and_type(node_evt, XML_TAG.GROUP, pGroup, pGroupType);
	node_mis = xml:child_with_name(node_grp, XML_TAG.MISSION, pMissionCode);
	node_sta = xml:child_with_name(node_mis, XML_TAG.STATION, pStation);
	if node_sta ~= nil then
		local func = xml:first_child(node_sta, XML_TAG.FUNCTION);
		if func == nil then
			nodes_msg = xml:children(node_sta, XML_TAG.MSG);
			return buildMessage(nodes_msg, pEvent, pGroup, pGroupType, pDefault, pContext);
		else
			nodes_func = xml:children(node_sta, XML_TAG.FUNCTION);
			local count = 1;
			for _,func in ipairs(nodes_func) do
				callFunction(func, pGroup, getPriority(pEvent, count), pDefault, pContext);
				count = count + 1;
			end;
			return {};
		end;
	end;
	return {};
end;

function mGetPredefMessage(pPredefId, pGroup, pGroupType, pDefault, pContext)
	util.trace( "mGetPredefMessage", util.L3 );
	node_predef = xml:child_with_name(xml:root(), XML_TAG.PREDEF, pPredefId);
	if node_predef ~= nil then
		returnedList = {};
		node_grp = xml:child_with_name_and_type(node_predef, XML_TAG.GROUP, pGroup, pGroupType);
		
		if node_grp ~= nil then
			local func = xml:first_child(node_grp, XML_TAG.FUNCTION);
			if func == nil then
				nodes_msg = xml:children(node_grp, XML_TAG.MSG);
				return buildMessage(nodes_msg, events.PREDEF, pGroup, pGroupType, pDefault, pContext);
			else
				nodes_func = xml:children(node_sta, XML_TAG.FUNCTION);
				local count = 1;
				for _,func in ipairs(nodes_func) do
					callFunction(func, pGroup, getPriority(events.PREDEF, count), pDefault, pContext);
					count = count + 1;
				end;
				return {};
			end;
		end;
	end;
	return nil;
end;

-- event introspection functions:
function mIsSpecialEvt( pEvt )
	local isSpecialEvt = false;
	for i = 1, table.getn( gSpecialEvtList ) do
		if gSpecialEvtList[i] == pEvt then
			isSpecialEvt = true;
			break;
		end;
	end;
	return isSpecialEvt;
end;

function mIsMissionEvt( pEvt )
	local isMissEvt = false;
	for i = 1, table.getn( gMissionEvtList ) do
		if gMissionEvtList[i] == pEvt then
			isMissEvt = true;
			break;
		end;
	end;
	return isMissEvt;
end;

function mIsStationEvt( pEvt )
	local isStatEvt = false;
	for i = 1, table.getn( gStationEvtList ) do
		if gStationEvtList[i] == pEvt then
			isStatEvt = true;
			break;
		end;
	end;
	return isStatEvt;
end;

-- variable replacement functions:
function mReplaceVariables( pStringWithVar, gDefault, pContext )
	util.trace( "mReplaceVariables for string : "..tostring(pStringWithVar), util.L3 );
	pStringWithVar = mReplaceComparisonOp(pStringWithVar);
	for var, _ in pairs(gDictionaryVariablesList) do
		local lOldString = "";
		while lOldString ~= pStringWithVar do
			lOldString = pStringWithVar;
			pStringWithVar = mReplaceVariable(pStringWithVar, var, pContext);
		end;
	end;
	
	for var, _ in pairs(gStaticVariablesList) do
		local lOldString = "";
		while lOldString ~= pStringWithVar do
			lOldString = pStringWithVar;
			pStringWithVar = mReplaceVariable(pStringWithVar, var, pContext);
		end;
	end;

	for var, val in pairs(gDictionaryInfoVariablesList) do
		local lOldString = "";
		while lOldString ~= pStringWithVar do
			lOldString = pStringWithVar;
			pStringWithVar = mReplaceInfoVariable(pStringWithVar, var, val[1], gDefault, pContext);
		end;
	end;
	
	for var, val in pairs(gStaticInfoVariablesList) do
		local lOldString = "";
		while lOldString ~= pStringWithVar do
			lOldString = pStringWithVar;
			pStringWithVar = mReplaceInfoVariable(pStringWithVar, var, val[1], gDefault, pContext);
		end;
	end;
	
	return pStringWithVar;
end;

function mReplaceComparisonOp(pInStr)
	local lRetStr = pInStr;
	if string.find(pInStr, "\\gt;")~= nil then
		lRetStr = string.gsub( lRetStr, "\\gt;", ">" );
	end;
	if string.find(lRetStr, "\\lt;")~= nil then
		lRetStr = string.gsub( lRetStr, "\\lt;", "<" );
	end;
	return lRetStr;
end;

function mReplaceVariable(pInStr, pVariable, pContext)
	if string.find(pInStr, pVariable)~= nil then
		local lValue = pContext[pVariable];
		if lValue == nil then
			util.trace( "mReplaceVariable: unknown variable: "..pVariable, util.LW );
			lValue = "";
		end;
		local lRetStr = string.gsub( pInStr, pVariable, tostring(lValue) );
		return lRetStr;
	 else
		return pInStr;
	end
end;

function mReplaceInfoVariable(pInStr, pVariable, pTag, pDefaultType, pContext)
	if string.find(pInStr, pVariable)~= nil then
		local lValue = pContext[pVariable];
		if lValue == nil then
			util.trace( "mReplaceInfoVariable: unknown variable: "..pVariable, util.LW );
			lValue = "";
		end;
		local lInfo = "";
		local lVariable = pVariable;
		
		local lRet,_,lType = string.find(pInStr, pVariable.."%[([^%]]+)%]");
		if lRet ~= nil then
			lVariable = lVariable .. "%[" .. lType .. "%]";
			lInfo = mGetInfo(pTag, lType, lValue, pContext);
		else
			-- default type
			util.trace( "mReplaceInfoVariable with default type", util.L3 );
			lInfo = mGetInfo(pTag, pDefaultType, lValue, pContext);
		end;
		
		local lRetStr = string.gsub( pInStr, lVariable, lInfo );
		return lRetStr;
	else
		return pInStr;
	end
end;

-- condition validity function:
function mCheckCondition(pCondition, pDefault, pContext)
	util.trace("mCheckCondition : "..tostring(pCondition), util.L3);
	pCondition = mReplaceVariables(pCondition, pDefault, pContext);
	local func = loadstring("return " .. pCondition);
	if func == nil then
		util.trace("Invalid condition : " .. pCondition, util.LE);
		return false;
	else
		return func();
	end;
end;

-- private functions:
function buildMessage(pMsgNodes, pEvent, pGroup, pGroupType, pDefault, pContext)
	util.trace( "buildMessage ".. tostring(pEvent).." "..tostring(pGroup).." "..tostring(pGroupType), util.L3 );
	local lMessageInfoList = {};
	local count = 0;
	
	for _,lMsgNode in ipairs(pMsgNodes) do
		local templateId = xml:attribute(lMsgNode, XML_TAG.TEMPLATE);
		local condition = xml:attribute(lMsgNode, XML_TAG.CONDITION);
		local duration = xml:attribute(lMsgNode, XML_TAG.DURATION);
		local messageId = xml:node_value(lMsgNode);
		local messageList = {};
		local templateList = {};
		
		if (condition == nil) or (mCheckCondition(condition, pDefault, pContext)) then
			local template = nil;
			if templateId ~= nil then
				node_template = xml:child_with_name(xml:root(), XML_TAG.TEMPLATE, templateId);
				node_lang = xml:child_with_name(node_template, XML_TAG.LANG, pContext["=LANG="]);
				node_val = xml:first_child(node_lang, XML_TAG.VALUE);
				template = xml:node_value(node_val);
			end;

			if messageId ~= nil then
				util.trace( "buildMessage messageId:" .. tostring(messageId), util.L4 );
				node_text = xml:child_with_name(xml:root(), XML_TAG.DATA, messageId);
				node_lang = xml:child_with_name(node_text, XML_TAG.LANG, pContext["=LANG="]);
				nodes_val = xml:children(node_lang, XML_TAG.VALUE);

				for _,val in ipairs(nodes_val) do
					local txt = xml:node_value(val);
					if txt ~= nil then
						txt = mReplaceVariables(txt, pDefault, pContext);
					end;
					if txt == nil then
						txt = "";
					end;
					table.insert(messageList, txt);
				end;
			else
				util.trace( "buildMessage : No message in xml file", util.LE );
			end;

			count = count + 1;
			local priority = getPriority(pEvent, count);
			table.insert(lMessageInfoList, {["group"] = pGroup, ["messageList"] = messageList, ["template"] = template, ["duration"] = duration, ["priority"] = priority});
		else
			util.trace( "buildMessage false condition", util.L3 );
		end;
	end;
	return lMessageInfoList;
end;

function callFunction(pFuncNode, pGroup, pPriority, pDefault, pContext)
	util.trace( "callFunction", util.L3 );

	local lCondition = xml:attribute(pFuncNode, XML_TAG.CONDITION);
	if (lCondition == nil) or (mCheckCondition(lCondition, pDefault, pContext)) then
		local lName = xml:attribute(pFuncNode, XML_TAG.NAME);
		local lParamNodes = xml:children(pFuncNode, XML_TAG.PARAM);
		local lParams = {};
		for _,lParamNode in ipairs(lParamNodes) do
			local lType = xml:attribute(lParamNode, XML_TAG.TYPE);
			
			if lType == XML_TAG.LITERAL then
				local txt = xml:node_value(lParamNode);
				if txt == nil then
					txt = "";
				end;
				table.insert(lParams, txt);
			elseif lType == XML_TAG.MSG then
				node_text = xml:child_with_name(xml:root(), XML_TAG.DATA, xml:node_value(lParamNode));
				node_lang = xml:child_with_name(node_text, XML_TAG.LANG, pContext["=LANG="]);
				nodes_val = xml:children(node_lang, XML_TAG.VALUE);

				local lMessageList = {};
				for _,val in ipairs(nodes_val) do
					local txt = xml:node_value(val);
					if txt == nil then
						txt = "";
					end;
					table.insert(lMessageList, txt);
				end;
				table.insert(lParams, lMessageList);
			elseif lType == XML_TAG.TEMPLATE then
				node_template = xml:child_with_name(xml:root(), XML_TAG.TEMPLATE, xml:node_value(lParamNode));
				node_lang = xml:child_with_name(node_template, XML_TAG.LANG, pContext["=LANG="]);
				node_val = xml:first_child(node_lang, XML_TAG.VALUE);
				table.insert(lParams, xml:node_value(node_val));
			else
				-- should never happen : invalid in xsd
				util.trace( "ERROR: invalid type for function parameter in callFunction: " .. tostring(lType), util.LE );
			end;
		end;
		table.insert(lParams, pGroup);
		table.insert(lParams, pPriority);
		_G[lName](unpack(lParams));
	end;
end;

function getPriority(pEvent, pCount)
	util.trace( "getPriority for "..pEvent, util.L3 );
	local lPriority = nil;
	if mIsSpecialEvt(pEvent) == true then
		lPriority =  matrix_priority.SPECIAL_MSG;
	elseif mIsMissionEvt(pEvent) == true then
		if pCount == 1 then
			lPriority =  matrix_priority.MISSION_EVT;
		else
			lPriority =  matrix_priority.MISSION_EVT_FILLER;
		end;
	elseif mIsStationEvt(pEvent) == true then
		if pCount == 1 then
			lPriority =  matrix_priority.STATION_EVT;
		else
			lPriority =  matrix_priority.STATION_EVT_FILLER;
		end;
	elseif pEvent == events.PREDEF then
		if pCount == 1 then
		  lPriority =  matrix_priority.SPECIAL_MSG;
		else
		  lPriority =  matrix_priority.SPECIAL_MSG_FILLER;
		end;
	else
		lPriority =  matrix_priority.LOW_EVT;
	end;
	return lPriority;
end;
