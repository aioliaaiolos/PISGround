--=============================================================================================
--Description : 400T LCD display functions
--=============================================================================================
--
-- 11/08/2010, P. Rival
-- Correction CR ALPHA00193401: R�organisation scripts PIS
--
-- 11/08/2010, P. Rival
-- Correction CR ALPHA00191954: PIS: d�lestage
--    Ajout de la fonction mSet400TEcoEnergyMode
--
-- 25/08/2010, P. Rival
-- Impl�mentation CR ALPHA00194046: gestion des modes par le syst�me PIS
--   Ajout des fonctions mClear400TDisplays et m400TSetMode et de la variable gMode
--   Nettoyage du code
--   Utilisation des m�mes d�lais pour l'affichage des pages
--   Utilisation du niveau de log L5 pour tous les logs
--
-- 27/08/2010, P. Rival
-- Merge des scripts de base dans les scripts de mission
--   Utilisation de variables globales � la place d'acc�s au dictionnaire pour r�cup�rer
--   le mode courant
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 28/01/2011, A. Lafont de Sentenac
-- Corrections suite � tests sur MI09
--
-- 04/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00216215: Contenu M�dia : matrice de priorit� pour 400T
--
-- 15/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00217088: Contenu media : 400T.lua code � supprimer
-- Correction CR ALPHA00217090: Contenu media : 400T gestion d'affichage altern�
-- Impl�mentation CR ALPHA00217747: Contenu m�dia : uniformisation des attributs de dur�e
--
-- 18/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00217090: Contenu media : 400T gestion d'affichage altern�
--
-- 31/03/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00224741: Contenu m�dia : la dur�e du play des 400T doit �tre en secondes et pas en millisecondes
--
-- 04/04/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00224741: Contenu m�dia : la dur�e du play des 400T doit �tre en secondes et pas en millisecondes
--
--=============================================================================================

gAlternate400TTaskList = {};
g400tTimerList = {};
gInfiniteDuration = 1000000; -- 1M sec, more than 10 days

function mUpdate400tDisplays(pEvent, pGroup, pStation, pContext)
	util.trace( "mUpdate400tDisplays "..pEvent.." - "..pGroup, util.L1 );
	local missionCode = pContext["=MISSION_CODE="];
	local station = "*";
	if pStation  ~= nil then
		station = pContext[pStation];
		util.trace( "mUpdate400tDisplays for station "..station, util.L3 );
	end;
	-- traitement update 400t
	stop400tTimers(pGroup);
	mPlay400tMessages(mGetEventMessage(pEvent, pGroup, g400tGroupType, missionCode, station, gDefaultStationName, pContext));
end;
	
function mPlay400tMessages(pMessageInfoList)
	util.trace( "mPlay400tMessages", util.L3 );
	for _,lMessageInfo in ipairs(pMessageInfoList) do
		local lPageUrl = "";
		for _,lMessage in ipairs(lMessageInfo.messageList) do
			lPageUrl = lPageUrl .. lMessage;
		end;
		
		local lDuration = getValidDuration(lMessageInfo.duration);
		player400t.play(lMessageInfo.priority, lMessageInfo.group, gWebDir .. lPageUrl, lDuration, tag.MISSION_MESSAGE );
	end;
end;

-- 400T initialisation function
function mInit400T( pMatrix )
	util.trace( "mInit400T", util.L1 );
	-- Init 400t player
	player400t.set_dmatrix(pMatrix);  
end;

function mSet400TEcoEnergyMode( pMode )
	util.trace( "mSet400TEcoEnergyMode", util.L3 );

	if( pMode == true ) then
		player400t.turn_backlight_off( player400t.GROUP_ALL_DISPLAYS );
	else
		player400t.turn_backlight_on( player400t.GROUP_ALL_DISPLAYS );
	end;  
end;

function mStartAlternate400TTask(pGroup, pMessageList, pDuration, pPriority)
	util.trace( "mStartAlternate400TTask", util.L1 );
	--create and start timer use to update frontal display content
	stop400tTimers(pGroup);
	if #pMessageList > 0 then
		local timerId = timer.create( alternate400TTaskBegin(pGroup, gInfiniteDuration, pPriority), pDuration*1000 );
		if g400tTimerList[pGroup] == nil then
			g400tTimerList[pGroup] = {};
		end;
		table.insert(g400tTimerList[pGroup], timerId);
		gAlternate400TTaskList[pGroup] = {pMessageList, 1};
		timer.start( timerId );
	end;
end;

function alternate400TTaskBegin(pGroup, pDuration, pPriority)
	return
	(function ()
		local context = mBuildContext();
		local lIndex = gAlternate400TTaskList[pGroup][2];
		local lMsg = gAlternate400TTaskList[pGroup][1][lIndex];
		lIndex = lIndex + 1;
		if lIndex > #gAlternate400TTaskList[pGroup][1] then
			lIndex = 1;
		end;
		gAlternate400TTaskList[pGroup][2] = lIndex;
		
		local messageList = {};
		table.insert(messageList, mReplaceVariables(lMsg, gDefaultStationName, context));
		
		local lPageUrl = mReplaceVariables(lMsg, gDefaultStationName, context);		
		player400t.play(pPriority, pGroup, lPageUrl, pDuration, tag.MISSION_MESSAGE );
	end)
end;

function stop400tTimers(pGroup)
	if g400tTimerList[pGroup] ~= nil then
		for _,lTimer in ipairs(g400tTimerList[pGroup]) do
			timer.stop(lTimer);
			timer.destroy(lTimer);
		end;
		g400tTimerList[pGroup] = nil;
	end;
end;

function getValidDuration(pDuration)
	local lDuration = tonumber(pDuration);
	if lDuration == 0 then
		-- infinite not correctly handled by product
		util.trace( "400T.lua: Duration set to infinite ("..tostring(gInfiniteDuration)..")", util.L4 );
		lDuration = gInfiniteDuration; 
	elseif lDuration < 5 then
		util.trace( "400T.lua: Duration ("..tostring(pDuration).." seconds) is to small for product. Set to 5 seconds!", util.LW );
		lDuration = 5; -- product does not support less than 5 sec
	end;
	return tostring(lDuration);
end;
