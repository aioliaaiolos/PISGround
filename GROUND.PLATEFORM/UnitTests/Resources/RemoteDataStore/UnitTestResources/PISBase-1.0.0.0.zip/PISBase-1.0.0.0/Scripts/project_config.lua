--
-- Generated
--

dofile( base_pack.SCRIPT_DIR .. "100t.lua" );
dofile( base_pack.SCRIPT_DIR .. "400t.lua" );
dofile( base_pack.SCRIPT_DIR .. "drm.lua" );
dofile( base_pack.SCRIPT_DIR .. "audio.lua" );
dofile( base_pack.SCRIPT_DIR .. "project_specific.lua" );
dofile( base_pack.SCRIPT_DIR .. "predef.lua" );
dofile( base_pack.SCRIPT_DIR .. "base_events.lua" );

function mInitProject(pDisplayMatrix)
	util.trace("mInitProject", util.L1);
	gCurrentMode = const_train.ACTIVE_MODE;
	mInit100T(pDisplayMatrix);
	mInit400T(pDisplayMatrix);
	mInitAudio(pDisplayMatrix);
	mInitProjectSpecific(pDisplayMatrix);
end;

function mStopProject()
	util.trace("mStopProject", util.L1);
	mStop100T(player100t.GROUP_ALL_DISPLAYS);
	mStopAudio(matrix_priority.SPECIAL_MSG, const_audio.ALL);
	gCurrentMode = const_train.INACTIVE_MODE;
	mStopProjectSpecific();
end;

function mInitVariables()
	util.trace("mInitVariables", util.L1);
	xml:from_file(base_pack.SCRIPT_DIR .. "base_announcements.xml");
	gDictionaryVariablesList = {
       ["=MISSION_CODE="] = "PIS.Input.MissionCode"
	};
	gStaticVariablesList = {
		["=LANG="] = "fr-FR"
	};
	gDictionaryInfoVariablesList = {
       ["=CURRENT_STATION="] = {"station", "PIS.Input.CurrentStationCode"},
       ["=DESTINATION="] = {"station", "PIS.Input.DestinationStationCode"},
       ["=NEXT_STATION="] = {"station", "PIS.Input.NextStationCode"}
	};
	gStaticInfoVariablesList = {};
	gSilenceVariable = "=SILENCE=";
	gMissionEvtList = { "MI", "ME" };
	gStationEvtList = { "SA", "SR", "SS", "SD", "SDD1", "SDD2", "SDD3", "SAL", "SRL", "SSL" };
	gSpecialEvtList = { "CLG", "WSG" };
	
	gSoundDir = base_pack.SOUND_DIR;
	gWebDir = base_pack.WEB_DIR;
	-- configure priority matrix:
	gSpecialOnMission = dmatrix.TEMP_OVERRIDE;
	gStationOnMission = dmatrix.WAIT;
	gSpecialOnStation = dmatrix.OVERRIDE;
	gMissionOnStation = dmatrix.OVERRIDE;
	gMissionOnSpecial = dmatrix.WAIT;
	gStationOnSpecial = dmatrix.WAIT;
	mInitProjectSpecificVariables();
end;
function mSetEvents()
	util.trace("mSetEvents", util.L1);
	-- Base events
    dictionary.subscribe(gDictionary, variables.SPECIAL_MESSAGE_EVENT, OnPredefMessage, false);
	dictionary.subscribe(gDictionary, "PIS.Input.CleaningMode", OnCLG, false);
	dictionary.subscribe(gDictionary, "PIS.Input.CleaningMode", OnWSG, false);
	mSetProjectSpecificEvents();
end;

