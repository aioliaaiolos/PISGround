--=============================================================================================
-- Description : Base script
--=============================================================================================
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 28/01/2011, A. Lafont de Sentenac
-- Corrections suite � tests sur MI09
--
-- 18/02/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00217588: Contenu M�dia : Gestion des PLD
--
-- 02/03/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00219578: Contenu M�dia : D�coupage des scripts en Base et Mission pour PackMaker
--
-- 31/03/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00224965: Contenu Media : Param�trage de la matrice de priorit�
--
--=============================================================================================

dofile( base_pack.SCRIPT_DIR .. "xml.lua" );
dofile( base_pack.SCRIPT_DIR .. "resource_accessor.lua" );
dofile( base_pack.SCRIPT_DIR .. "events.lua" );
dofile( base_pack.SCRIPT_DIR .. "project_config.lua" );

xml = nil;
gDictionary = nil;
gDisplayMatrix = nil;

--=============================================================================================
-- Function : _Initialization
-- Description :
-- called when the mission starts
-----------------------------------------------------------------------------------------------
-- No parameter
--==============================================================================================
function _Initialization( )
	util.trace( "base.lua::_Initialization", util.L1 );

	xml = XML:new();
	mInitResources( );
	mInitDisplayDecisionMatrix( );
	mInitProject(gDisplayMatrix);
	
	-- Create dictionary object
	gDictionary = dictionary.create( );
	-- Connect to data dictionary (0: TRAIN_LOCAL)
	if ( dictionary.connect( gDictionary, 0, nil ) ) then 
		util.trace( "base.lua::_Initialization - Connected to dictionary", util.L5 );
		-- Initialize the event manager
		evtmgr.init( gDictionary ); 
		mSetEvents();
		-- Start event manager
		evtmgr.run();
	end;
end;


function mInitDisplayDecisionMatrix( )
	util.trace( "initDisplayDecisionMatrix", util.L1 );

	-- Create decision matrix
	gDisplayMatrix = dmatrix.create( 12 );
	
	-- I: Ignore, W: Wait, O: Override, TO: Temp Override
	--                                   current								new
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.FT_URGENT,            dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.FT_NORMAL,            dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.SUSPEND,              dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.CLEAR,                dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.SPECIAL_MSG,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.MISSION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.STATION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_BLANK,				matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.FT_NORMAL,            dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.SUSPEND,              dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.CLEAR,                dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.SPECIAL_MSG,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.MISSION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.STATION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_URGENT,				matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.SUSPEND,              dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.CLEAR,                dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.SPECIAL_MSG,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.MISSION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.STATION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.FT_NORMAL,				matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.SUSPEND,              dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.CLEAR,                dmatrix.IGNORE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.SPECIAL_MSG,          dmatrix.IGNORE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.IGNORE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.MISSION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.STATION_EVT,          dmatrix.IGNORE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.STATION_EVT_FILLER,   dmatrix.IGNORE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SUSPEND,				matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.SUSPEND,              dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.SPECIAL_MSG,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.MISSION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.STATION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.CLEAR,					matrix_priority.LOW_EVT,              dmatrix.WAIT );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.SPECIAL_MSG,          dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.MISSION_EVT,          gMissionOnSpecial );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.STATION_EVT,          gStationOnSpecial );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG,			matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.SPECIAL_MSG,          dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.MISSION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.STATION_EVT,          dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.SPECIAL_MSG_FILLER,	matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.SPECIAL_MSG,          gSpecialOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.SPECIAL_MSG_FILLER,   gSpecialOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.MISSION_EVT,          dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.STATION_EVT,          gStationOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.STATION_EVT_FILLER,   gStationOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT,			matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.SPECIAL_MSG,          gSpecialOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.SPECIAL_MSG_FILLER,   gSpecialOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.MISSION_EVT,          dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.MISSION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.STATION_EVT,          gStationOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.STATION_EVT_FILLER,   gStationOnMission );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.MISSION_EVT_FILLER,	matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.SPECIAL_MSG,          gSpecialOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.SPECIAL_MSG_FILLER,   gSpecialOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.MISSION_EVT,          gMissionOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.MISSION_EVT_FILLER,   gMissionOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.STATION_EVT,          dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT,			matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.SPECIAL_MSG,          gSpecialOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.SPECIAL_MSG_FILLER,   gSpecialOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.MISSION_EVT,          gMissionOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.MISSION_EVT_FILLER,   gMissionOnStation );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.STATION_EVT,          dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.STATION_EVT_FILLER,   dmatrix.WAIT );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.STATION_EVT_FILLER,	matrix_priority.LOW_EVT,              dmatrix.IGNORE );

	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.FT_BLANK,             dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.FT_URGENT,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.FT_NORMAL,            dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.SUSPEND,              dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.CLEAR,                dmatrix.OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.SPECIAL_MSG,          dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.SPECIAL_MSG_FILLER,   dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.MISSION_EVT,          dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.MISSION_EVT_FILLER,   dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.STATION_EVT,          dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.STATION_EVT_FILLER,   dmatrix.TEMP_OVERRIDE );
	dmatrix.insert_rule( gDisplayMatrix, matrix_priority.LOW_EVT,				matrix_priority.LOW_EVT,              dmatrix.OVERRIDE );    
end;

function destroyDisplayDecisionMatrix( )
	util.trace( "destroyDisplayDecisionMatrix", util.L1 );
	dmatrix.destroy( gDisplayMatrix );
end;

--=============================================================================================
-- Function : _Finalization
-- Description :
-- called when the mission stops
-----------------------------------------------------------------------------------------------
-- No parameter
--==============================================================================================
function _Finalization( )
	util.trace( "base.lua::_Finalization", util.L1 );
	-- Stop event manager
	evtmgr.stop( );
	-- Disconnect from data dictionary
	dictionary.disconnect( gDictionary );
	dictionary.destroy( gDictionary );
	destroyDisplayDecisionMatrix( );
	mStopProject( );
end;