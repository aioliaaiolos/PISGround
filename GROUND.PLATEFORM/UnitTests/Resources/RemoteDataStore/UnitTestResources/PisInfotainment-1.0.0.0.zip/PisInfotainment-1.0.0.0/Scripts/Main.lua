--=============================================================================================
-- Script Name                  : Main.lua
-- Script Description           : 
-- Applicable Project           : 
-- Sub-systems impacted         : 
-- Creation Date                : 2011/02/14
-- Contact person               : 
-- Script Editor Version        : PIS2G
-- Script Revision              : V01
-- SRN                          :
-- --------------------------------------------------------------------------------------------
-- |  date:   |   Fonction Name:         | Create/Modify/Remove:  |    Change description:    |
-- --------------------------------------------------------------------------------------------
-- 
-- --------------------------------------------------------------------------------------------
-- Complementary Notes   : 
--
--=============================================================================================

--=============================================================================================
--Fonction            : _Initialization()
--Description         : Script initialization function. Called when the script should be started.
--Note                : 
--=============================================================================================
function _Initialization()
 -- util.trace("_Initialization!!!", util.L5);
  
  --refDic = dictionary.create();
  
  -- Connect to the dictionary
 -- if (dictionary.connect(refDic, dictionary.TRAIN_LOCAL, nil)) then
    --util.trace("Connection with dictionary has been established.", util.L5);

    --InitReport(); 
    --StartInfotainment();
  --else
    --util.trace("Connection with dictionary has failed. ","Check the connection with the system under test.", util.L5);
  --end;
  
  
end;
  
function InitReport()
  util.trace("InitReport", util.L5);  
  headerTable = { {"Date/time", "DateTime.Local"}, "VideoName", "State"};
  reportRef = report.open("InfoRep.txt", report.MODE_APPEND, headerTable, refDic);
end;


function StartInfotainment()
	util.trace("StartInfotainment", util.L5); 
  	
    avstream.configure_channel(avstream.CHANNEL1_ID, avstream.CHANNEL1_URL, avstream.PROTOCOL_RTP, OnStreamNotification);
    g400tRef = player400t.start_listen_stream(priority.PREDEFINED_LOW, player400t.GROUP_ALL_DISPLAYS, avstream.CHANNEL1_ID, OnShowVideoViewer,  OnHideVideoViewer);	 
  
end;

function OnShowVideoViewer(pChannelId)
    util.trace ("OnShowVideoViewer", util.L5);  
    avstream.play_stream(avstream.CHANNEL1_ID);
end;

function OnHideVideoViewer(pChannelId)
    util.trace ("OnHideVideoViewer", util.L5); 
    avstream.pause_stream(avstream.CHANNEL1_ID)	
end;


function OnStreamNotification(pNotificationCode, pChannelId)
  util.trace ("OnStreamNotification", util.L5);
  if (pNotificationCode == avstream.NOTIFICATION_PLAYING) then
    util.trace ("Stream Playing", util.L5);
	report.write(reportRef, avstream.get_current_video(pChannelId), "STARTED");
  end;

  if (pNotificationCode == avstream.NOTIFICATION_PAUSED) then
	util.trace ("Stream Paused", util.L5);
	report.write(reportRef, avstream.get_current_video(pChannelId), "PAUSED");
  end;
  
  if (pNotificationCode == avstream.NOTIFICATION_STOPPED) then
    util.trace ("Stream Stopped", util.L5);
	report.write(reportRef, avstream.get_current_video(pChannelId), "STOPPED");
  end;

  if (pNotificationCode == avstream.NOTIFICATION_ENDED) then
    util.trace ("Stream ended", util.L5);
	report.write(reportRef, avstream.get_current_video(pChannelId), "ENDED");
  end;
  
  if (pNotificationCode == avstream.NOTIFICATION_PLAYLIST_ENDED) then
    util.trace ("Playlist Ended", util.L5);
  end;
  
  if (pNotificationCode == avstream.NOTIFICATION_ERROR) then
    util.trace ("Stream Error", util.L5);
	report.write(reportRef, avstream.get_current_video(pChannelId), "ERROR");
  end;  
  
end;


--=============================================================================================
--Fonction            : _Finalization()
--Description         : Script uninitialization function. Called when the script should be stopped.
--Note                : 
--=============================================================================================
function _Finalization()

  --util.trace("_Finalization", util.L5);
  
  --player400t.stop_listen_stream(player400t.GROUP_ALL_DISPLAYS, avstream.CHANNEL1_ID, g400tRef);    
  --avstream.stop_stream(avstream.CHANNEL1_ID);   
  --report.close(reportRef); 
  --dictionary.disconnect(refDic);
  --dictionary.destroy(refDic);
end;