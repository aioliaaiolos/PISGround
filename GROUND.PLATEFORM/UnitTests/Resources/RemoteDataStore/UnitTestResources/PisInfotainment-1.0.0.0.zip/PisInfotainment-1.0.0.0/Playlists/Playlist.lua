--=============================================================================================
-- Script Name                  : Infotainment.lua
-- Script Description           : 
-- Applicable Project           : 
-- Sub-systems impacted         : 
-- Creation Date                : 2011/02/14
-- Contact person               : 
-- Script Editor Version        : PIS2G
-- Script Revision              : V01
-- SRN                          :
-- --------------------------------------------------------------------------------------------
-- |  date:   |   Fonction Name:         | Create/Modify/Remove:  |    Change description:    |
-- --------------------------------------------------------------------------------------------
--=============================================================================================

--=============================================================================================
--Fonction            : _Initialization()
--Description         : Script initialization function. Called when the script should be started.
--Note                : 
--=============================================================================================
function _Initialization()

  --util.trace("_Initialization!!!", util.L5); 
  -- Initialize Playlist.
  --InitPlaylist();
  
end;
  

function InitPlaylist()

    -- infotainment_pack.VIDEO_DIR.."PIS_Passenger_Information.mp4",
    -- infotainment_pack.VIDEO_DIR.."PIS_Incident Management.mp4",
  
	util.trace("Initializing Playlist", util.L1);
	pl1 = playlist.create(playlist.RECURRING);
	
	playlist.add(pl1, infotainment_pack.VIDEO_DIR.."Corpo1.mp4");
	playlist.add(pl1, infotainment_pack.VIDEO_DIR.."Wildlife.mp4");
--	playlist.add(pl1, infotainment_pack.VIDEO_DIR.."softboy_720x320_mpeg4.avi");
--	playlist.add(pl1, infotainment_pack.VIDEO_DIR.."PIS_Wireless Connectivity.mp4");
	
	avstream.assign_playlist(avstream.CHANNEL1_ID, pl1);   -- Assign makes a copy of pl1 and assigns it to Channel1.
	util.trace("assigned Playlist", util.L1);
	playlist.destroy(pl1); -- no problem to destroy pl1 since a copy has already been made in the assign statement.
end;


--=============================================================================================
--Fonction            : _Finalization()
--Description         : Script uninitialization function. Called when the script should be stopped.
--Note                : 
--=============================================================================================
function _Finalization()
  --util.trace("_Finalization", util.L5);
end;