--[[
Fichier Generic.lua

Ce fichier traite les evenement de tracking comme TSDO, SD, SA ou SS

C'est ici que l'on va lier les evenement de mission avec les callbacks de pancartage

]]

dofile("F:/PIS Files/PIS Base/Scripts/Background/DisplayUtils.lua");
dofile("F:/PIS Files/PIS Base/Scripts/Background/Texte.lua");
dofile("F:/PIS Files/PIS Base/Scripts/Background/PancartageLED.lua");
dofile("F:/PIS Files/PIS Base/Scripts/Background/DiffusionAudio.lua");

-- Variables de parametrage du StoryBoard
Delai_TSD0 = 120
Delai_Inter_Page = 5

gLangueActiveTab = {language.FRA} ;
gMainLanguage = {language.FRA} ;
gNombreDePageGaresDesservies = 1

nbGareParPage = 5 ; -- Fixe, ne peux pas changer dynamiquement vu les templates des pages Flash
refDic = nil

gTrainNumber = 0 ;
gQuaiCourt = false ;
gWMode = false;

gVe1ExtremeSoiree = false;
gViuExtremeSoiree = false;
gVc1ExtremeSoiree = false;
gVc2ExtremeSoiree = false;
gVi2ExtremeSoiree = false;
gVe2ExtremeSoiree = false;
gNbCar = -1;

function _Initialization()
    util.trace("ManualMission: _Initialization", util.L1);
    
    missionInfo = {}
    missionInfo[language.FRA] =  {};
    missionInfo[language.ENG] =  {};
    missionInfo[language.GER] =  {};
    missionInfo[language.ITA] =  {};
    
    missionConnectionInfo = nil
   
    -- Cr�ation d'une instance de dictionnaire
    refDic = dictionary.create() ;
    
    util.trace("Connection au dictionnaire local...", util.L1);
    if (dictionary.connect(refDic, dictionary.TRAIN_LOCAL, nil)) then
         util.trace("Connect� au dictionnaire local !", util.L1);
         
        -- Initiation du gestionnaire d'�venement
        evtmgr.init(refDic)
        
        evtmgr.add_varargs( "Mission.FirstStation.SNCFCode" );
        evtmgr.add_varargs( "Mission.EventStation.SNCFCode" );
        evtmgr.add_varargs( "Mission.RemainStationList.SNCFCodes" );
        --evtmgr.add_varargs( "Mission.QuaiCourt" );
        evtmgr.add_varargs( "Mission.SegmentCommercialNumber" );
        evtmgr.add_varargs( "Mission.Type" );
        
        dictionary.subscribe(refDic, "Dplg.Train.Modele", onTrainModele, true);
      
        evtmgr.add_mission_event(evtmgr.DEGRADED_TRACKING, onDegMissionInit, evtmgr.LANGUAGE_LIST_BY_CALL);           
        
        
        evtmgr.add_mission_event(evtmgr.MISSION_NOT_INIT, onMissionNotInit, evtmgr.LANGUAGE_LIST_BY_CALL);   
        -- Lancement du gestionnaire d'�venement
        evtmgr.run();
    end
     util.trace("ManualMission: _Initialization END", util.L1);
end;


---- GESTION DE L'EVENEMENT NI - Mission non initialis�e -----
function onMissionNotInit(pEvent, pLanguageTabMission)
    util.trace("PIS Mission Manuelle:MissionNotInit called on1 "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    
    -- Arreter les cycles joues par Mission mais pas les pages pour que Base continue d afficher
    StopPageAndCycle( false )
end


function onDegMissionInit(pEvent, pLanguageTabMission, pVariables)
    util.trace("onDegMissionInit called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    gMissionType = pVariables["Mission.Type"]
    gLangueActiveTab = Shift(pLanguageTabMission);
    gMainLanguage = gLangueActiveTab[0]
    InitPagesCycle(Delai_Inter_Page) ;
    
    for i=0, #gLangueActiveTab do
        -- On recupere le nombre de remaining_station pour calculer le nombre de page
        util.trace("Getting mission Info for "..gLangueActiveTab[i], util.L5) ;
        missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
        if( i == 0) then
            -- On a 5 gares affichees par page
            local remainingStationNumber = util.get_item_count(missionInfo[gMainLanguage].remaining_station_names)
            gNombreDePageGaresDesservies = math.ceil(remainingStationNumber / nbGareParPage )
            util.trace("Nombre de Page Calcul�:gNombreDePageGaresDesservies="..gNombreDePageGaresDesservies, util.L5) ;
        end
        
        AddPageToCycle("C1_DEG", gLangueActiveTab[i]) ;
		
        --On recupere les info de mission pour chaque langue active
        util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
       
    end
    
    AfficherPagesMultilingue( 0) ;
    
    
    Stop_Pancartage_Frontaux();
    Stop_Pancartage_Lateraux("100T-LAT", tag.MISSION_MESSAGE);
    Stop_Pancartage_Lateraux("100T-LAT", tag.TRAIN_MESSAGE);
    --Pancartage_Frontaux_Destination();			--on affiche rien sur les frontaux
    --Pancartage_Lateraux_Desserte(true, "DEG");	--on affiche rien sur les lateraux
    Pancartage_Interieurs_Degrade("100T-INT");
    --Pancartage_150T_Desserte(true, "DEG");
    
     
end



function onTrainModele(pName, pValue)
  util.trace("manual mission: onTrainModele with pName = "..tostring(pName).." and value = "..tostring(pValue), util.L2);
  gConfPacis = pValue;
  if ( (pValue==0) or (pValue==2) or (pValue == 3) or (pValue == 5) or (pValue == 6) ) then
    gNbCar = 6;
    gOS06 = false; --true;--suppression de l option quai court ALPHA00301240
  elseif   ( (pValue == 1) or (pValue == 4) or (pValue == 7) or (pValue == 8) or (pValue == 9) or (pValue ==11) or (pValue == 12) or (pValue == 13) ) then
    gNbCar = 4;
    gOS06 = false; --true;--suppression de l option quai court ALPHA00301240
  elseif   ( (pValue == 10) or (pValue == 14) ) then
    gNbCar = 4;
    gOS06 = false;  
  else
    util.trace("manual mission: onTrainModele valeur inattendue = "..tostring(pValue), util.L3);
  end
end




function _Finalization()
    util.trace("Generic: _Finalization", util.L1);

    evtmgr.stop();
     
    -- D�connexion du dictionnaire
    util.trace("Deconnection du Dictionnaire...", util.L1);
    if(dictionary.isconnected( refDic ) )  then
        dictionary.disconnect(refDic);
    end
   
    -- Destruction du dictionnaire
    util.trace("Destruction du dictionnaire...", util.L1);
    if( refDic ~= nil ) then
        dictionary.destroy(refDic);
    end
end;

