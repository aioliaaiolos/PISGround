--[[
Fichier GroundRequests.lua

Ce fichier s'execute en parallele du script Generic.

C'est ici que l'on va faire les demandes au Sol pour pouvoir
exploiter les donnees Sol dans les Flashs

17/10/2012, C.MARTIN
suppression de l option quai court ALPHA00301240 [PIS] atvcm00141378 - suppression OS6 fonctionnel porte hors quai
fonction impactees onTrainModele, onStationDeparture

]]

-- ###################### variables globales et parametres ########################
gOperatorId = "";
gPhysicalId = "";
gCommercialNumber = "";
gConfPacis = -1;
gNbCar = -1;

function _Initialization()
    util.trace("**********************GroundRequests: _Initialization...", util.L1);
       
    refGround = ground.create();
    refTimer = timer.create( OnGetDelay, 30000 );
    ref2Dic = dictionary.create() ;
    
    util.trace("**********************GroundRequests:Connection au dictionnaire local...", util.L1);
    if (dictionary.connect(ref2Dic, dictionary.TRAIN_LOCAL, nil)) then
         util.trace("**********************GroundRequests:Connect� au dictionnaire local !", util.L1);
         
         -- Recuperation du N� de conf PACIS
        dictionary.subscribe(ref2Dic, "Dplg.Train.Modele", onTrainModele, true);

        -- Initiation du gestionnaire d'�venement
        evtmgr.init(ref2Dic)
        
        evtmgr.add_varargs( "Vehicle.PhysicalIdentifier" );
        evtmgr.add_varargs( "Mission.OperatorID" );
        evtmgr.add_varargs( "Mission.SegmentCommercialNumber" );
        evtmgr.add_varargs( "Mission.NextStation.IUICCode" );
        evtmgr.add_varargs( "Mission.NextStation.ArrivalDateTime" );
        evtmgr.add_varargs( "Mission.EventStation.IUICCode" );
        
        evtmgr.add_mission_event(evtmgr.MISSION_INIT, onMissionInit, evtmgr.LANGUAGE_LIST_BY_CALL); 
        evtmgr.add_tracking_event(evtmgr.STATION_DEPARTURE, onStationDeparture, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_tracking_event(evtmgr.STATION_APPROACH, onStationApproach, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_tracking_event(evtmgr.STATION_ARRIVAL, onStationArrival, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_mission_event(evtmgr.MISSION_END, onMissionEnd, evtmgr.LANGUAGE_LIST_BY_CALL);      
        -- Lancement du gestionnaire d'�venement
        evtmgr.run();
    end
    
    util.trace("**********************GroundRequests:BaseMainScript: _Initialization Done !", util.L1);  
    
end;

function onMissionInit(pEvent, pLanguageTabMission, pArgs)
  util.trace("**********************GroundRequests:onMissionInit called on "..pEvent, util.L2);
    
  gOperatorId = pArgs["Mission.OperatorID"];
  gPhysicalId = pArgs["Vehicle.PhysicalIdentifier"];
  gCommercialNumber = pArgs["Mission.SegmentCommercialNumber"];
  util.trace("OPERATOR ID="..gOperatorId, util.L5);
  util.trace("CommercialNumber = "..tostring(gCommercialNumber), util.L5);
  --start timer to get periodically the delay
  timer.start( refTimer );
end

function onStationDeparture(pEvent, pLanguageTabMission, pStationId, pArgs)
  util.trace("**********************GroundRequests:onStationDeparture called on "..pEvent, util.L2);
  util.trace("**********************TEST="..pArgs["Mission.NextStation.IUICCode"], util.L2);
  ground.query_connections(refGround, gPhysicalId, gOperatorId, gCommercialNumber, pArgs["Mission.NextStation.IUICCode"], pArgs["Mission.NextStation.ArrivalDateTime"]);
end

function onStationApproach(pEvent, pLanguageTabMission, pStationId, pArgs)
  util.trace("**********************GroundRequests:onStationApproach called on "..pEvent, util.L2);
  util.trace("**********************TEST="..pArgs["Mission.NextStation.IUICCode"], util.L2);
  ground.query_connections(refGround, gPhysicalId, gOperatorId, gCommercialNumber, pArgs["Mission.NextStation.IUICCode"], pArgs["Mission.NextStation.ArrivalDateTime"]);    
    
end

function onStationArrival(pEvent, pLanguageTabMission, pStationId, pArgs)
  util.trace("**********************GroundRequests:onStationApproach called on "..pEvent, util.L2);
  util.trace("**********************TEST="..pArgs["Mission.NextStation.IUICCode"], util.L2);
  ground.query_connections(refGround, gPhysicalId, gOperatorId, gCommercialNumber, pArgs["Mission.NextStation.IUICCode"], pArgs["Mission.NextStation.ArrivalDateTime"]);    
    
end

function onMissionEnd(pEvent, pLanguageTabMission)
    util.trace("**********************GroundRequests:onMissionEnd called on "..pEvent, util.L2);
    
    timer.stop( refTimer );
    gCommercialNumber = "";
    gOperatorId = "";
    gPhysicalId = "";
end


function OnGetDelay()
  util.trace("**********************GroundRequests:OnGetDelay called ", util.L2);
  util.trace("gPhysicalId=" .. gPhysicalId .."gOperatorId=" .. gOperatorId .. " gCommercialNumber = " .. gCommercialNumber, util.L2);
  ground.query_delay( refGround, gPhysicalId, gOperatorId, gCommercialNumber);
  
end

function _Finalization()
    util.trace("**********************GroundRequests: _Finalization...", util.L1);
    
    evtmgr.stop();
    
    if ( refGround ~= nil ) then
      ground.destroy( refGround );
    end;
    
    if ( refTimer ~= nil ) then
      timer.stop( refTimer );
      timer.destroy( refTimer );
    end; 
    
    -- D�connexion du dictionnaire
    util.trace("**********************GroundRequests:econnection du Dictionnaire...", util.L1);
    if(dictionary.isconnected( ref2Dic ) )  then
        dictionary.disconnect(ref2Dic);
    end
   
    -- Destruction du dictionnaire
    util.trace("**********************GroundRequests:Destruction du dictionnaire...", util.L1);
    if( ref2Dic ~= nil ) then
        dictionary.destroy(ref2Dic);
    end
    
    
end