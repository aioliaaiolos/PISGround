--[[
Fichier Generic.lua

Ce fichier traite les evenement de tracking comme TSDO, SD, SA ou SS

C'est ici que l'on va lier les evenement de mission avec les callbacks de pancartage

07/08/2012, C.MARTIN
corrections ALPHA00294038, ALPHA00293834 et bugs non repertories
    fonctions impactees: onExtremeSoireeGenericTest et onExtremeSoiree
    ajout de variable pour connaitre l etat du SIVE : NI SS SSL...

09/08/2012, C.MARTIN
Int�gration remarques suite a relecture de code (concerne onExtremeSoireeGenericTest onTrainStopped onMissionNotInit onMissionInit onTSD0 
onStationDeparture onStationStop onStationStopLast onMissionEnd)
changement changement des noms de variable et ajustement du code

17/09/2012, C.MARTIN
CR ALPHA00296009    [PIS] Pas de mise a jour de la diffusion sur les afficheurs a LED et les annonces sonores suite a un recalage manuel
Ajout de la gestion du recalage en SS
    fonctions impactees: OnSivMissRSP et onStationStop

17/10/2012, C.MARTIN
suppression de l option quai court ALPHA00301240 [PIS] atvcm00141378 - suppression OS6 fonctionnel porte hors quai
    fonctions impactees: onTrainModele, onStationApproach, onStationApproachLast

10/01/2013, F.CHAUVIN
CR ALPHA00330675: ajout d une annonce audio en SD
    fonction impactee: onStationDeparture
]]

dofile("F:/PIS Files/PIS Base/Scripts/Background/DisplayUtils.lua");
dofile("F:/PIS Files/PIS Base/Scripts/Background/Texte.lua");
dofile("F:/PIS Files/PIS Base/Scripts/Background/PancartageLED.lua");
dofile("F:/PIS Files/PIS Base/Scripts/Background/DiffusionAudio.lua");

-- ###################### matrice de priorite et tag associes ########################
priority_MessageModeW = 4
priority_MessageConjImp = 3
priority_MessageMConjNorm = 2
priority_MessageMission = 1
priority_MessageNI = 0
priorityPA_MessageConjImp = 7
priorityPA_MessageMConjNorm = 6
priorityPA_MessageMission = 5
--tag.INSTANT_MESSAGE = ?       utilise pour les MsgConj Imp
--ok tag.MISSION_MESSAGE = 1 
--tag.TRAIN_MESSAGE = 3         utilise pour les Msg en mode W
tag_AllMessages = 0            -- ce tag n est pas utilise dans les fonctions player.stop 

-- ###################### variables globales et parametres ########################
Delai_TSD0 = 120
Delai_Inter_Page = 5
nbGareParPage = 5 ; -- Fixe, ne peux pas changer dynamiquement vu les templates des pages Flash

-- DEFINITION des variables gloables
refDic = nil
gLangueActiveTab = {language.FRA} ;
gListArg = nil;
gMainLanguage = {language.FRA} ;
gNombreDePageGaresDesservies = 1
gNombreDePageCorrespondanceTrain = 1
gNombreDePageCorrespondanceInter = 1
gActiveCabin = -1;
gCommercialNumber = "";
gConfPacis = -1;
gOS06 = false;			-- option Fonctionnel portes hors quai
gNbCar = -1;
gWMode = false;
gTrainStopped = false;
gDoorOpenAuth = false;
gExitSide = -1;
gVe1ExtremeSoiree = false;
gViuExtremeSoiree = false;
gVc1ExtremeSoiree = false;
gVc2ExtremeSoiree = false;
gVi2ExtremeSoiree = false;
gVe2ExtremeSoiree = false;
gArretPartiel = true;
gBddCodeSive = "";

gNIState = false;
gSSState = false;
gSSLState = false;
gOldonExtremeSoireeVar = 0;
gOldESMDetail = { false, false, false, false, false, false };

gRecalageSS = false;



function _Initialization()
    util.trace("Generic: _Initialization", util.L1);
    
    missionInfo = {}
    missionInfo[language.FRA] =  {};
    missionInfo[language.ENG] =  {};
    missionInfo[language.GER] =  {};
    missionInfo[language.ITA] =  {};
    
    missionConnectionInfo = nil
    
    -- on charge de suite les templates car ils seront appeles dans les subscribe  
    util.trace("Chargement des Templates 100T." , util.L1);
    player100t.load_templates(base_pack.LED_DISPLAY_TEMPLATE_DIR.."DisplayTemplateConfiguration.xml")
       
    -- Cr�ation d'une instance de dictionnaire
    refDic = dictionary.create() ;
    
    util.trace("Connection au dictionnaire local...", util.L1);
    if (dictionary.connect(refDic, dictionary.TRAIN_LOCAL, nil)) then
        util.trace("Connect� au dictionnaire local !", util.L1);
                              
-- Dans l'ordre, on appelle 
-- 1. subscribe Cabine,N� train, Conf PACIs car utilise dans l'evt NI
-- 2. puis on lance les evts

        -- Gestion pour l'affichage sur les LED Frontaux, on selectionne le groupe en fonction de la cabine active
        dictionary.subscribe(refDic, "Vehicle.ActiveCabin", onActiveCabin, true);
        
        -- Recuperation du N� de conf PACIS
        dictionary.subscribe(refDic, "Dplg.Train.Modele", onTrainModele, true);
                
        -- Recuperation du cote ouverture porte
        dictionary.subscribe(refDic, "Vehicle.ExitSide", onExitSide, true);

        -- Recuperation du mode W
        dictionary.subscribe(refDic, "Vehicle.EmptyState", onWMode, true);
        
        -- gestion/detection train arrete en mode Extreme soiree
        dictionary.subscribe(refDic, "Vmc_IExtremeSoiree", onExtremeSoiree, true );

        -- gestion du lancement mission en mode modifie
        dictionary.subscribe(refDic, "VMC_ARRET_PARTIEL", OnArretPartiel, true );
        
        -- gestion du lancement mission en mode modifie
        dictionary.subscribe(refDic, "SIV-MISSION-BDD-CODE-SIV", OnBddCodeSiv, true );
		
		-- gestion de l affichage de la mission modifie
		dictionary.subscribe(refDic, "SIV-MISSION-INSERTION-RSP", OnSivMissRSP, false );
        
        -- Initiation du gestionnaire d'�venement
        evtmgr.init(refDic)
        
        evtmgr.add_varargs( "Mission.FirstStation.SNCFCode" );
        evtmgr.add_varargs( "Mission.EventStation.SNCFCode" );
        evtmgr.add_varargs( "Mission.RemainStationList.SNCFCodes" );
        evtmgr.add_varargs( "Mission.SegmentCommercialNumber" );
        evtmgr.add_varargs( "Vmc_local_EPU_Alive" );
      
        evtmgr.add_mission_event(evtmgr.MISSION_INIT, onMissionInit, evtmgr.LANGUAGE_LIST_BY_CALL);                                     
        evtmgr.add_tracking_time_before_event(evtmgr.STATION_DEPARTURE, Delai_TSD0, onTSD0, evtmgr.LANGUAGE_LIST_BY_CALL);	
        evtmgr.add_tracking_event(evtmgr.STATION_DEPARTURE, onStationDeparture, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_tracking_event(evtmgr.STATION_APPROACH, onStationApproach, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_tracking_event(evtmgr.STATION_STOP, onStationStop, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_tracking_event(evtmgr.STATION_APPROACH_LAST, onStationApproachLast, evtmgr.LANGUAGE_LIST_BY_CALL);
        evtmgr.add_tracking_event(evtmgr.STATION_STOP_LAST, onStationStopLast, evtmgr.LANGUAGE_LIST_BY_CALL);--
        evtmgr.add_mission_event(evtmgr.MISSION_END, onMissionEnd, evtmgr.LANGUAGE_LIST_BY_CALL);       
        evtmgr.add_mission_event(evtmgr.MISSION_NOT_INIT, onMissionNotInit, evtmgr.LANGUAGE_LIST_BY_CALL);   
        -- Lancement du gestionnaire d'�venement
        evtmgr.run();
        -- gestion/detection train arrete en mode W
        dictionary.subscribe(refDic, "Epu_Bbr_ISpdThrh05", onTrainStopped, false );
        dictionary.subscribe(refDic, "Siv_IDoorOpenAuthLeft", onTrainStopped, false );
        dictionary.subscribe(refDic, "Siv_IDoorOpenAuthRight", onTrainStopped, false ); 
                       
        -- detection quai court
        dictionary.subscribe(refDic, "PP.PotentialShortPlatformTrigger", onShortPlatformTrigger, false);        
                
    end
      
end;



-- Callback qui traite une modification de la variable Vehicle.ActiveCabin
-- En fonction de sa valeur, 1 ou 0, on va pancarter sur le groupe de ANNAX frontal "avant" ou "arriere"
function onActiveCabin(pName, pValue)
  util.trace("Generic: onActiveCabin called with value = "..tostring(pValue), util.L2);
  gActiveCabin = pValue;
end


-- Callback qui recupere le N� de conf lu dans le dataplug
function onTrainModele(pName, pValue)
  util.trace("Generic: onTrainModele with pName = "..tostring(pName).." and value = "..tostring(pValue), util.L2);
  gConfPacis = pValue;
  if ( (pValue==0) or (pValue==2) or (pValue == 3) or (pValue == 5) or (pValue == 6) ) then
    gNbCar = 6;
    gOS06 = false; --true;--suppression de l option quai court ALPHA00301240
  elseif   ( (pValue == 1) or (pValue == 4) or (pValue == 7) or (pValue == 8) or (pValue == 9) or (pValue ==11) or (pValue == 12) or (pValue == 13) ) then
    gNbCar = 4;
    gOS06 = false; --true;--suppression de l option quai court ALPHA00301240
  elseif   ( (pValue == 10) or (pValue == 14) ) then
    gNbCar = 4;
    gOS06 = false;  
  else
    util.trace("Generic: onTrainModele valeur inattendue = "..tostring(pValue), util.L3);
  end
end


-- Callback qui recupere l etat du Mode W
function onWMode(pName, pValue)
  util.trace("Generic: onWMode with value = "..tostring(pValue), util.L2); 
  -- mise a jour de la variable globale
  gWMode = pValue;  
  -- appel de la fonction gerant le pancartage
  ManageWMode(pValue);
end


-- Callback qui recupere le cote du quai
function onExitSide(pName, pValue)
  util.trace("Generic: onExitSide with pName = "..tostring(pName).." and value = "..tostring(pValue), util.L2);
  gExitSide = pValue;
end



function onExtremeSoireeGenericTest(pValue, CarNumber, DefaultVxxESMVar)
	if ( (pValue%2) == 1) then
		if(gOldESMDetail[CarNumber] == false)then
			gOldESMDetail[CarNumber] = true;
			player400t.turn_backlight_off("LCD-"..Liste_Voiture[CarNumber]);
			return PancLatSansVoyagESMGeneric(CarNumber, true, true);--gTrainStopped, gDoorOpenAuth)
		else
			util.trace("onExtremeSoiree: pas de changement Voiture "..tostring(CarNumber).." panc", util.L1);
			return DefaultVxxESMVar;
		end;
	else
		if(gOldESMDetail[CarNumber] == true)then
			gOldESMDetail[CarNumber] = false;
			player400t.turn_backlight_on("LCD-"..Liste_Voiture[CarNumber]);
			local ltmploc = UnPancLatSansVoyagESMGeneric(CarNumber, true);-- on n est pas en extreme soiree
			if ( gSSLState == true ) then
				Pancartage_Interieurs_Terminus("INTERIEUR_CAR_"..tostring(CarNumber));--on restaure les 100T INT qui ne sont plus en extreme soiree
			elseif( gNIState ~= true ) then
				Pancartage_Interieurs_Desserte("INTERIEUR_CAR_"..tostring(CarNumber));--on restaure les 100T INT qui ne sont plus en extreme soiree
			end;
			return ltmploc;
		else
			util.trace("onExtremeSoiree: pas de changement Voiture "..tostring(CarNumber).." unpanc", util.L1);
			return DefaultVxxESMVar;
		end;
	end;
end;

-- callback pour gerer le mode extreme soiree.
-- dans Generic, on met uniquement a jour les variables globales
function onExtremeSoiree(pName, pValue)
  util.trace("Generic: onExtremeSoiree called on "..tostring(pName).." with value = "..tostring(pValue), util.L2);
  if (gNIState == false)then
	  local lVxxExtremeSoiree = 0;
	  if (pValue == 0) then
		 -- il faut gerer la transition de mode extreme soiree ACTIF A INACTIF 
		 if (gVe1ExtremeSoiree == true) then
		   UnPancLatSansVoyagESMGeneric(1, true);
		 end;
		 if (gViuExtremeSoiree == true) then
		   UnPancLatSansVoyagESMGeneric(2, true);
		 end;
		 if (gVc1ExtremeSoiree == true) then
		   UnPancLatSansVoyagESMGeneric(3, true);
		 end;
		 if (gVc2ExtremeSoiree == true) then
		   UnPancLatSansVoyagESMGeneric(4, true);
		 end;
		 if (gVi2ExtremeSoiree == true) then
		   UnPancLatSansVoyagESMGeneric(5, true);
		 end;
		 if (gVe2ExtremeSoiree == true) then
		   UnPancLatSansVoyagESMGeneric(6, true);
		 end;
		 gVe1ExtremeSoiree = false;
		 gViuExtremeSoiree = false;
		 gVc1ExtremeSoiree = false;
		 gVc2ExtremeSoiree = false;
		 gVi2ExtremeSoiree = false;
		 gVe2ExtremeSoiree = false;
		 gOldESMDetail[1] = false;
		 gOldESMDetail[2] = false;
		 gOldESMDetail[3] = false;
		 gOldESMDetail[4] = false;
		 gOldESMDetail[5] = false;
		 gOldESMDetail[6] = false;
		 gOldonExtremeSoireeVar = pValue;
		 util.trace("onExtremeSoiree: pas de voiture en mode extreme soiree OU pas d option extreme soiree", util.L1);
		 Restore100TStateESM(gOldESMDetail); -- a confirmer pour l'emplacement de cette fonction
	  else
		
		-- test mode extreme soiree Ve1 (bit0)
		gVe1ExtremeSoiree = onExtremeSoireeGenericTest(pValue, 1, gVe1ExtremeSoiree);
		
		-- test mode extreme soiree Vi Ufr (bit1)
		lVxxExtremeSoiree = macro_RShift(pValue, 1);
		gViuExtremeSoiree = onExtremeSoireeGenericTest(lVxxExtremeSoiree, 2, gViuExtremeSoiree);
		
		-- test mode extreme soiree Vc1 (bit2)
		lVxxExtremeSoiree = macro_RShift(pValue, 2);
		gVc1ExtremeSoiree = onExtremeSoireeGenericTest(lVxxExtremeSoiree, 3, gVc1ExtremeSoiree);
		
		-- test mode extreme soiree Vc2 (bit3)
		lVxxExtremeSoiree = macro_RShift(pValue, 3);
		gVc2ExtremeSoiree = onExtremeSoireeGenericTest(lVxxExtremeSoiree, 4, gVc2ExtremeSoiree);
		
		-- test mode extreme soiree Vi2 (bit4)
		lVxxExtremeSoiree = macro_RShift(pValue, 4);
		gVi2ExtremeSoiree = onExtremeSoireeGenericTest(lVxxExtremeSoiree, 5, gVi2ExtremeSoiree);
		
		-- test mode extreme soiree Ve2 (bit5)
		lVxxExtremeSoiree = macro_RShift(pValue, 5);
		gVe2ExtremeSoiree = onExtremeSoireeGenericTest(lVxxExtremeSoiree, 6, gVe2ExtremeSoiree);
		
		if (gOldonExtremeSoireeVar ~= pValue)then
			Restore100TStateESM(gOldESMDetail);
			gOldonExtremeSoireeVar = pValue;
		end;
	  end;
	end;
end;

--function handling a change on Epu_Bbr_ISpdThrh05
function onTrainStopped(pName, pValue)
  util.trace("Generic: onTrainStopped called on "..tostring(pName).." with value = "..tostring(pValue), util.L2);
  local lWMode = false
  local lExtremeSoiree = -1
  -- mise a jour des variables globales
  if ( (pName == "Epu_Bbr_ISpdThrh05") and (pValue == false) ) then
    gTrainStopped = true;
  elseif ( (pName == "Epu_Bbr_ISpdThrh05") and (pValue == true) ) then   
    gTrainStopped = false;
  elseif ( ((pName == "Siv_IDoorOpenAuthLeft") and (pValue == false)) or ((pName == "Siv_IDoorOpenAuthRight") and (pValue == false)) ) then
    gDoorOpenAuth = false;
  elseif ( ((pName == "Siv_IDoorOpenAuthLeft") and (pValue == true))or ((pName == "Siv_IDoorOpenAuthRight") and (pValue == true)) ) then
    gDoorOpenAuth = true;
  else
    util.trace("Generic: onTrainStopped cas inattendu", util.L3);
  end  
  -- detection d un arret en gare 
  if ( (gTrainStopped == true) and (gDoorOpenAuth == true) ) then
    lWMode = dictionary.getvalue( refDic, "Vehicle.EmptyState");
    if ( lWMode == true ) then
      onWMode( "Vehicle.EmptyState", lWMode);
    else
      util.trace("Generic: onTrainStopped: pas de mode W donc pas d appel a la fonction onWMode", util.L3);
    end
  else
    util.trace("Generic: onTrainStopped train n est pas encore arrete en gare", util.L3);
  end

end


-- Callback pour recuperer le lancement de mission en mode modifie
function OnArretPartiel(pName, pValue)
  util.trace("Generic: OnArretPartiel with pName = "..tostring(pName).." and value = "..tostring(pValue), util.L2);
  gArretPartiel = pValue;
end

function OnBddCodeSiv(pName, pValue)
  util.trace("Generic: OnBddCodeSiv with pName = "..tostring(pName).." and value = "..tostring(pValue), util.L2);
  gBddCodeSive = pValue;
end
---- GESTION DE L'EVENEMENT NI - Mission non initialis�e -----
function onMissionNotInit(pEvent, pLanguageTabMission)
    util.trace("Generic:MissionNotInit called on1 "..pEvent.." ArretPartiel = "..tostring(gArretPartiel).." BddCodeSive= "..tostring(gBddCodeSive), util.L2);
    gNIState = true;--informe que l on rentre en mode NI
	gSSState = false;
    if ( (gArretPartiel == false) and (gBddCodeSive == "") ) then
      -- Arreter les cycles joues par Mission mais pas les pages pour que Base continue d afficher
      StopPageAndCycle( false, tag_AllMessages)
    else
      util.trace("Generic:onMissionNotInit: lancement de mission en mode modifie donc il ne faut rien faire",util.L5);  
    end
end


function onMissionInit(pEvent, pLanguageTabMission, pArgs)
    util.trace("Generic:onMissionInit called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L1);
	if( pArgs ~= nil) then
		util.trace("mise a jour gListArg", util.L1);
		gListArg = pArgs
	end;
    local lGroupNameToDisplay = "";
    local lGroupNameValueToPlay = 0
    gCommercialNumber = pArgs["Mission.SegmentCommercialNumber"];
	if(pLanguageTabMission ~= nil) then
		gLangueActiveTab = Shift(pLanguageTabMission);
	end;
    gMainLanguage = gLangueActiveTab[0]
    InitPagesCycle(Delai_Inter_Page) ;
	gNIState = false; --informe que l on quitte le mode NI
	gSSState = true; --indique que l on est en SS (hypothese)
    
    for i=0, #gLangueActiveTab do
        -- On recupere le nombre de remaining_station pour calculer le nombre de page
        missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
        if( i == 0) then
            -- On a 5 gares affichees par page
            local remainingStationNumber = util.get_item_count(missionInfo[gMainLanguage].remaining_station_names)
            gNombreDePageGaresDesservies = math.ceil(remainingStationNumber / nbGareParPage )
            util.trace("Nombre de Page Calcul�:gNombreDePageGaresDesservies="..gNombreDePageGaresDesservies, util.L5) ;
        else
            util.trace("onMissionInit erreur inattendue car i ne vaut pas 0", util.L5) ;
        end
        
        AddPageToCycle("B1", gLangueActiveTab[i]) ;
        AddPageToCycle("GaresDesservies", gLangueActiveTab[i]) ;
        
        --On recupere les info de mission pour chaque langue active
        util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
       
    end
    AddPageToCycle("Region", gMainLanguage) ;
    AddPageToCycle("Evenement", gMainLanguage) ;
    AfficherPagesMultilingue(0) ;
    
    
    Pancartage_Frontaux_Destination();
    -- La console permettant de lancer une mission est dispo uniquement a l arret
    -- donc pas besoin de tester si arret avant de pancarter sur les LAT
    Pancartage_Interieurs_Desserte("100T-INT");
       
end
    

function onTSD0(pEvent, pLanguageTabMission, pStationCode, pVariables)
    util.trace("Generic:onTSD0 called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    local lGroupNameToDisplay = ""
    local lGroupNameValueToPlay = 0
	gSSState = true; --indique que l on est en SS a verifier
    
    -- Ici on verifie d'etre a la premiere station pour jouer un TSDO
    if( pVariables["Mission.EventStation.SNCFCode"] == pVariables["Mission.FirstStation.SNCFCode"] ) then
        util.trace("onTSD0 traited for First Station", util.L2);
        
        gLangueActiveTab = Shift(pLanguageTabMission);
        gMainLanguage = gLangueActiveTab[0] ;
       
        InitPagesCycle(Delai_Inter_Page) ;
        
        for i=0, #gLangueActiveTab do
            util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
            missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
            if( i == 0) then
                -- On a 5 gares affichees par page
                local remainingStationNumber = util.get_item_count(missionInfo[gMainLanguage].remaining_station_names)
                gNombreDePageGaresDesservies = math.ceil(remainingStationNumber / nbGareParPage )
                util.trace("Nombre de Page Calcul�:gNombreDePageGaresDesservies="..gNombreDePageGaresDesservies, util.L5) ;
            end
        
            AddPageToCycle("J1", gLangueActiveTab[i]) ;
            AddPageToCycle("J2", gLangueActiveTab[i]) ;
            AddPageToCycle("GaresDesservies", gLangueActiveTab[i]) ;
            
        end
        AddPageToCycle("Region", gMainLanguage) ;
        AddPageToCycle("Evenement", gMainLanguage) ;
        AfficherPagesMultilingue(0) ;
    
        Pancartage_Frontaux_Destination();
        
        Pancartage_Interieurs_Desserte("100T-INT");
        
        lGroupNameValueToPlay = CalculateAudioGroup();      
        Diffusion_Audio_Bienvenue(lGroupNameValueToPlay);
    
        evtmgr.remove_tracking_time_before_event(evtmgr.STATION_DEPARTURE);
    else 
         util.trace("onTSD0 NOT traited because NOT First Station", util.L2);
    end
	TestESMAndPrintLat();
	Restore100TStateESM(gOldESMDetail);
      
end

  
function onStationDeparture(pEvent, pLanguageTabMission)
    util.trace("Generic:onStationDeparture called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    local lGroupNameValueToPlay = 0;
    gLangueActiveTab = Shift(pLanguageTabMission);
    gSSState = false; -- on est plus en SS
    
    -- en SD, remise a zero de la variable indiquant un quai court dans la prochaine gare
    
    InitPagesCycle(Delai_Inter_Page) ;
    
    for i=0, #gLangueActiveTab do
        util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
        missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
        if( i == 0) then
            -- On a 5 gares affichees par page
            local remainingStationNumber = util.get_item_count(missionInfo[gMainLanguage].remaining_station_names)
            gNombreDePageGaresDesservies = math.ceil(remainingStationNumber / nbGareParPage )
            util.trace("Nombre de Page Calcul�:gNombreDePageGaresDesservies="..gNombreDePageGaresDesservies, util.L5) ;
        end
    
        AddPageToCycle("D1", gLangueActiveTab[i]) ;
        AddPageToCycle("Thermometre", gLangueActiveTab[i]) ;
        AddPageToCycle("GaresDesservies", gLangueActiveTab[i]) ;
        
    end
    AddPageToCycle("Region", gMainLanguage ) ;
    AddPageToCycle("Evenement", gMainLanguage ) ;
    AfficherPagesMultilingue(0) ;    
 
    Stop_Pancartage_Frontaux();
    Stop_Pancartage_Lateraux("100T-LAT", tag.MISSION_MESSAGE);
	Stop_Pancartage_Lateraux("100T-LAT", tag.TRAIN_MESSAGE);
    Pancartage_Interieurs_Desserte("100T-INT") ;
    
    -- CR ALPHA00330675: ajout d une annonce audio
    lGroupNameValueToPlay = CalculateAudioGroup(); 
    Diffusion_Audio_Depart(lGroupNameValueToPlay );
    
end


function onStationApproach(pEvent, pLanguageTabMission, pStationCode, pVariables)
    util.trace("Generic:onStationApproach called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    gLangueActiveTab = Shift(pLanguageTabMission);
    gMainLanguage = gLangueActiveTab[0]
    InitPagesCycle(Delai_Inter_Page) ;
	gSSState = false; -- on est pas en SS
    
    for i=0, #gLangueActiveTab do
        AddPageToCycle("D1", gLangueActiveTab[i]) ;
        AddPageToCycle("Thermometre", gLangueActiveTab[i]) ;
        AddPageToCycle("D1", gLangueActiveTab[i]) ;
        util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
        missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
    end
    --On affiche ces pages uniquement si on a des correspondances
    local nextStationCode = missionInfo[gMainLanguage].next_station.code ;
    util.trace("Recuperation info correspondance pour la gare:" .. nextStationCode, util.L3 ) ;
    missionConnectionInfo = mission_data.get_connection(nextStationCode, gMainLanguage )
    
    if( missionConnectionInfo ~= nil) then
        local nbConnection = #missionConnectionInfo.connection_list ;
        util.trace("Nombre de Correspondance a la prochaine Gare:" .. nbConnection, util.L3 ) ;
        if( nbConnection > 0) then
        
            local nbConnectiontrain = 0;
            local nbConnectionInter = 0;
            
            for i = 1, nbConnection, 1 do
                local typeName = missionConnectionInfo.connection_list[i].type_name
                if( typeName == "Train") then
                    nbConnectiontrain = nbConnectiontrain + 1 ;
                    
                else
                    nbConnectionInter = nbConnectionInter + 1 ;
                end
            
            end
            gNombreDePageCorrespondanceTrain = math.ceil(nbConnectiontrain / nbGareParPage )
            gNombreDePageCorrespondanceInter = math.ceil(nbConnectionInter / nbGareParPage )
            
            util.trace("Nombre de Correspondance TRAIN a la prochaine Gare:" .. nbConnectiontrain, util.L3 ) ;
            util.trace("Nombre de Correspondance INTER a la prochaine Gare:" .. nbConnectionInter, util.L3 ) ;
            
            AddPageToCycle("ListeTypeCorrespondance", gMainLanguage ) ;
            if( nbConnectiontrain > 0 ) then
                AddPageToCycle("CorrespondanceTrain", gMainLanguage ) ;
            end
            if( nbConnectionInter > 0 ) then
                AddPageToCycle("CorrespondanceInter", gMainLanguage ) ;
            end
        end
    end
    -- util.trace("onStationApproach: test current_station", util.L5);
    -- Pancartage_Interieurs_ArriveeImminente( false );
    -- 400T
	AfficherPagesMultilingue( 0 ) ;
	-- 100T: Frontaux
	Pancartage_Frontaux_Destination();
	-- 100T: LAT
	Stop_Pancartage_Lateraux("100T-LAT", tag.MISSION_MESSAGE);
	-- 100T: INT
    Pancartage_Interieurs_ArriveeImminente();
    -- Audio
    lGroupNameValueToPlay = CalculateAudioGroup(); 
    Diffusion_Audio_Approche(lGroupNameValueToPlay )
end

function onStationStop(pEvent, pLanguageTabMission, pStationId, pVariables)
	--util.trace("Generic:onStationStop called on "..pEvent.." "..pLanguageTabMission.." "..pStationId.." "..pVariables, util.L1);
	local EventStation = nil; --dictionary.getvalue(refDic, "Mission.EventStation.SNCFCode");
	if( pVariables ~= nil) then
		util.trace("mise a jour gListArg", util.L1);
		gListArg = pVariables
		EventStation = gListArg["Mission.EventStation.SNCFCode"]-- il semble que les pVariables n ai pas encore ete mise a jour par le pis quand recalage
		else
		EventStation = dictionary.getvalue(refDic, "Mission.EventStation.SNCFCode");-- il semble que les pVariables n ai pas encore ete mise a jour par le pis quand recalage
	end;
    --local EventStation = gListArg["Mission.EventStation.SNCFCode"] -- il semble que les pVariables n ai pas encore ete mise a jour par le pis quand recalage
    local FirstStation = gListArg["Mission.FirstStation.SNCFCode"]
    local lGroupNameToDisplay = ""
    local lGroupNameValueToPlay = 0
	gSSState = true; --indique que l on est en SS
    util.trace("Generic:onStationStop called on "..pEvent..", with languages: "..LanguageToString(gLangueActiveTab), util.L1);
	if (pLanguageTabMission ~= nil) then
		gLangueActiveTab = Shift(pLanguageTabMission);
	end;
    gMainLanguage = gLangueActiveTab[0]
   
    util.trace("onStationStop called on "..EventStation.." and FirsStation is "..FirstStation,util.L1);
    --util.trace("onStationStop called on "..pVariables["Mission.EventStation.SNCFCode"],util.L2);
    --On ne traite l'evenement SS que si on n'est pas a la gare d'origine
    if( (EventStation ~= FirstStation) or (gRecalageSS == true) ) then
        InitPagesCycle(Delai_Inter_Page) ;
        for i=0, #gLangueActiveTab do 
              util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
              missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
              if( i == 0) then
                -- On a 5 gares affichees par page
                local remainingStationNumber = util.get_item_count(missionInfo[gMainLanguage].remaining_station_names)
                gNombreDePageGaresDesservies = math.ceil(remainingStationNumber / nbGareParPage )
                util.trace("Nombre de Page Calcul�:gNombreDePageGaresDesservies="..gNombreDePageGaresDesservies, util.L5) ;
              end
              AddPageToCycle("C1", gLangueActiveTab[i]) ;
              AddPageToCycle("C2", gLangueActiveTab[i]) ;
              AddPageToCycle("GaresDesservies", gLangueActiveTab[i]) ;
            
        end
        AddPageToCycle("Region", gMainLanguage ) ;
        AddPageToCycle("Evenement", gMainLanguage ) ;
        AfficherPagesMultilingue(0) ;
             
        Pancartage_Frontaux_Destination() ;
        
        Pancartage_Interieurs_Desserte("100T-INT") ;
        
        lGroupNameValueToPlay = CalculateAudioGroup();     
        Diffusion_Audio_Arret(lGroupNameValueToPlay);
    end
	TestESMAndPrintLat(); --affichage des sans voyageur pour ESM
	Restore100TStateESM(gOldESMDetail);
end

function onStationApproachLast(pEvent, pLanguageTabMission, pStationCode, pVariables)
    util.trace("Generic:onStationApproachLast called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    gLangueActiveTab = Shift(pLanguageTabMission);
    gMainLanguage = gLangueActiveTab[0]
    InitPagesCycle(Delai_Inter_Page) ;
	gSSState = false; -- on est pas en SS
    for i=0, #gLangueActiveTab do
        AddPageToCycle("D1", gLangueActiveTab[i]) ;
        AddPageToCycle("Thermometre", gLangueActiveTab[i]) ;      
        AddPageToCycle("D1", gLangueActiveTab[i]) ;
        util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
        missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
    end
    
    --On affiche ces pages uniquement si on a des correspondances
    local nextStationCode = missionInfo[gMainLanguage].next_station.code ;
    util.trace("Recuperation info correspondance pour la gare:" .. nextStationCode, util.L3 ) ;
    missionConnectionInfo = mission_data.get_connection(nextStationCode, gMainLanguage)
    
    if( missionConnectionInfo ~= nil) then
        local nbConnection = #missionConnectionInfo.connection_list ;
        util.trace("Nombre de Correspondance a la prochaine Gare:" .. nbConnection, util.L3 ) ;
        if( nbConnection > 0) then
        
            local nbConnectiontrain = 0;
            local nbConnectionInter = 0;
            
            for i = 1, nbConnection, 1 do
                local typeName = missionConnectionInfo.connection_list[i].type_name
                if( typeName == "Train") then
                    nbConnectiontrain = nbConnectiontrain + 1 ;
                    
                else
                    nbConnectionInter = nbConnectionInter + 1 ;
                end
            
            end
            gNombreDePageCorrespondanceTrain = math.ceil(nbConnectiontrain / nbGareParPage )
            gNombreDePageCorrespondanceInter = math.ceil(nbConnectionInter / nbGareParPage )
            
            util.trace("Nombre de Correspondance TRAIN a la prochaine Gare:" .. nbConnectiontrain, util.L3 ) ;
            util.trace("Nombre de Correspondance INTER a la prochaine Gare:" .. nbConnectionInter, util.L3 ) ;
            
            AddPageToCycle("ListeTypeCorrespondance", gMainLanguage ) ;
            if( nbConnectiontrain > 0 ) then
                AddPageToCycle("CorrespondanceTrain", gMainLanguage ) ;
            end
            if( nbConnectionInter > 0 ) then
                AddPageToCycle("CorrespondanceInter", gMainLanguage ) ;
            end
        end
    end
    -- 400T
	AfficherPagesMultilingue( 0 ) ;
	-- 100T: Frontaux
	Pancartage_Frontaux_Destination();
	-- 100T: LAT
	Stop_Pancartage_Lateraux("100T-LAT", tag.MISSION_MESSAGE);
	-- 100T: INT
    Pancartage_Interieurs_ArriveeImminenteTerminus();
    -- Audio
    lGroupNameValueToPlay = CalculateAudioGroup(); 
    Diffusion_Audio_ApprocheTerminus( lGroupNameValueToPlay )
end

function onStationStopLast(pEvent, pLanguageTabMission)
    local lGroupNameToDisplay = ""
    local lGroupNameValueToPlay = 0
	gSSState = false;
	gSSLState = true;
    util.trace("Generic:onStationStopLast called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);
    gLangueActiveTab = Shift(pLanguageTabMission);
    gMainLanguage = gLangueActiveTab[0]
    InitPagesCycle(Delai_Inter_Page) ;
    util.trace("onStationStopLast: fin init Page",util.L5);
    for i=0, #gLangueActiveTab do
        AddPageToCycle("G1", gLangueActiveTab[i]) ;
        util.trace("Get Mission Info in "..gLangueActiveTab[i], util.L2);
        missionInfo[gLangueActiveTab[i]] = mission_data.get_mission_info(gLangueActiveTab[i]);
    end
    AfficherPagesMultilingue(0) ;
   
    Pancartage_Frontaux_Destination();
    
    Pancartage_Interieurs_Terminus("100T-INT") ;
    
    lGroupNameValueToPlay = CalculateAudioGroup(); 
    Diffusion_Audio_ArretTerminus( lGroupNameValueToPlay ) ;
	
	TestESMAndPrintLat(); --affichage des sans voyageur pour ESM
	Restore100TStateESM(gOldESMDetail);
end

function onMissionEnd(pEvent, pLanguageTabMission)
    local lGroupNameToDisplay = ""
    local lGroupNameValueToPlay = 0
    util.trace("Generic:onMissionEnd called on "..pEvent..", Languages: "..LanguageToString(pLanguageTabMission), util.L2);    
    gLangueActiveTab = Shift(pLanguageTabMission);
    gCommercialNumber = "";
    InitPagesCycle(Delai_Inter_Page) ;
    for i=0, #gLangueActiveTab do
        AddPageToCycle("NI", gLangueActiveTab[i]) ;
    end
    AfficherPagesMultilingue(0) ;
    
    lGroupNameToDisplay = Calculate100TGroup();
    Pancartage_Lateraux_SansVoyageur(lGroupNameToDisplay, priority_MessageMission);
    Pancartage_Interieurs_SansVoyageur("100T-INT");
    Pancartage_Frontaux_SansVoyageur("ME");
    
    lGroupNameValueToPlay = CalculateAudioGroup(); 
    Diffusion_Audio_SansVoyageur(lGroupNameValueToPlay) ;
      
end


function _Finalization()
    util.trace("Generic: _Finalization ArretPartiel "..tostring(gArretPartiel).." CodeSive= "..tostring(gBddCodeSive), util.L1);

    if ( (gArretPartiel == false) and (gBddCodeSive == "") ) then
      -- Arreter les cycles joues par Mission mais pas les pages pour que Base continue d afficher
      StopPageAndCycle( false, tag_AllMessages)
    else
      util.trace("Generic:Finalization: lancement de mission en mode modifie donc il ne faut rien faire",util.L5);  
    end
    evtmgr.stop();
     
    -- D�connexion du dictionnaire
    util.trace("Deconnection du Dictionnaire...", util.L1);
    if(dictionary.isconnected( refDic ) )  then
        dictionary.disconnect(refDic);
    end
   
    -- Destruction du dictionnaire
    util.trace("Destruction du dictionnaire...", util.L1);
    if( refDic ~= nil ) then
        dictionary.destroy(refDic);
    end
end;


function OnSivMissRSP(pName, pValue)
	local letat_mission = dictionary.getvalue(refDic, "Mission.State");
	local tmp_var = nil;
	util.trace("OnSivMissRSP: onsivchange",util.L2);
	if ( letat_mission == "SS" ) then
		--evtmgr.STATION_STOP()
		gRecalageSS = true;
		util.trace("OnSivMissRSP: STATIONSTOP "..tostring(evtmgr.STATION_STOP).." LANGUAGE_LIST_BY_CALL ",util.L2);
		onStationStop(evtmgr.STATION_STOP, tmp_var, tmp_var, tmp_var)
	end;
end;

