--=============================================================================================
-- Description : 100T display functions
--=============================================================================================
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 13/01/2011, A. Lafont de Sentenac
-- Gestion des fonctions depuis le XML
-- Gestion des timers
--
-- 28/01/2011, A. Lafont de Sentenac
-- Corrections suite � tests sur MI09
--
-- 04/02/2011, A. Lafont de Sentenac
-- Arr�t des timers uniquement mUpdate100tDisplays (pas sur tous les appels � mPlay100tMessages)
--
-- 15/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00217628: Contenu M�dia : Gestion de la priorit� lors des appels de fonctions
--
-- 17/02/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00217747: Contenu m�dia : uniformisation des attributs de dur�e
--
-- 25/03/2011, A. Girard
-- Correction CR ALPHA00217747: Contenu m�dia, Afficheurs frontaux : dur�e de l'alternance des pages sur alternate100TTaskBegin
--=============================================================================================

gCurrentDisplayDate = true;
gAlternate100TTaskList = {};
g100tTimerList = {};

function mUpdate100tDisplays(pEvent, pGroup, pStation, pContext)  
	util.trace( "mUpdate100tDisplays "..pEvent.." - "..pGroup, util.L1 );
	local missionCode = pContext["=MISSION_CODE="];
	local station = "*";
	if pStation  ~= nil then
		station = pContext[pStation];
		util.trace( "mUpdate100tDisplays for station "..station, util.L3 );
	end;
	-- traitement update 100t
	stop100tTimers(pGroup);
	mPlay100tMessages(mGetEventMessage(pEvent, pGroup, g100tGroupType, missionCode, station, gDefaultStationName, pContext));
end;

function mPlay100tMessages(pMessageInfoList)
	util.trace( "mPlay100tMessages", util.L3 );
	local lPageList = {};
	local lGroup = nil;
	for _,lMessageInfo in ipairs(pMessageInfoList) do
		if lMessageInfo.template ~= nil then
			lGroup = lMessageInfo.group;
			local lPage = buildPage(lMessageInfo.template, lMessageInfo.messageList, pContext)
			table.insert(lPageList, {[const_100t.GROUP] = lMessageInfo.group, [const_100t.PAGE] = lPage, [const_100t.DELAY] = lMessageInfo.duration, [const_100t.PRIORITY] = lMessageInfo.priority});
		else
			util.trace( "mUpdate100tDisplays : No associated template in xml file for "..tostring(pEvent), util.LE );
		end;
	end;
	
	if lGroup ~= nil then
		play100t(lPageList, lGroup);
	end;
end;

function mSuspend100TDisplays(pGroup)
	util.trace( "mSuspendLateral100TDisplays", util.L1 );
	local page = nil;
	page = player100t.create_page_from_template( const_100t.TEMPLATE_CENTER );
	player100t.print_text( page, const_100t.ZONE_CENTER, " ");		
	player100t.play( matrix_priority.SUSPEND, pGroup, 0, 10000, tag.MISSION_MESSAGE, page);
end;

function mResume100TDisplays(pGroup)
	util.trace( "mResumeLateral100TDisplays", util.L1 );
	local page = nil;
	page = player100t.create_page_from_template( const_100t.TEMPLATE_CENTER );
	player100t.print_text( page, const_100t.ZONE_CENTER, " ");		
	player100t.play( matrix_priority.SUSPEND, pGroup, 1, 10000, tag.MISSION_MESSAGE, page);  
end;

-- 100T initialisation function
function mInit100T( pMatrix )
	util.trace( "mInit100T", util.L1 );
	-- Init 100t player
	player100t.set_dmatrix(pMatrix);  
end;

function mStop100T( pGroup )
	player100t.stop(pGroup);
end;

function mStartAlternate100TTask(pMessageList1, pTemplate1, pMessageList2, pTemplate2, pDuration, pGroup, pPriority)
	--create and start timer use to update frontal display content
	stop100tTimers(pGroup);
	local timerId = timer.create( alternate100TTaskBegin(pGroup, pMessageList1, pTemplate1, pMessageList2, pTemplate2, pDuration, pPriority), pDuration*1000 );
	if g100tTimerList[pGroup] == nil then
		g100tTimerList[pGroup] = {};
	end;
	table.insert(g100tTimerList[pGroup], timerId);
	
	gAlternate100TTaskList[pGroup] = true;
	timer.start( timerId );
end;

function alternate100TTaskBegin(pGroup, pMessageList1, pTemplate1, pMessageList2, pTemplate2, pDuration, pPriority)
	return
	(function ()
		local context = mBuildContext();
		local lMsgList;
		local lTemplate;
		if gAlternate100TTaskList[pGroup] == true then
			lMsgList = pMessageList1;
			lTemplate = pTemplate1;
			gAlternate100TTaskList[pGroup] = false;
		else
			lMsgList = pMessageList2;
			lTemplate = pTemplate2;
			gAlternate100TTaskList[pGroup] = true;
		end;
		
		local messageList = {};
		for _,msg in ipairs(lMsgList) do
			table.insert(messageList, mReplaceVariables(msg, gDefaultStationName, context));
		end;
		local page = buildPage(lTemplate, messageList, context);
		local pagesList = {{[const_100t.GROUP] = pGroup, [const_100t.PAGE] = page, [const_100t.DELAY] = 0, [const_100t.PRIORITY] = pPriority}};
		play100t(pagesList, pGroup );
	end)
end;

function buildPage(pTemplate, pMessageList, pContext)
	util.trace( "buildPage", util.L3 );
	local lMessage = "";
	local page = player100t.create_page_from_template( pTemplate );
	for i = 1, table.getn( pMessageList ) do
		player100t.print_text( page, i-1, pMessageList[i]);
	end;
	return page;
end;

function play100t(pPageslist, pGroup)
	util.trace( "play100t ", util.L1 );
	for i = 1, table.getn( pPageslist ) do
		local page = pPageslist[i][const_100t.PAGE];
		local priority = pPageslist[i][const_100t.PRIORITY];
		local delay = pPageslist[i][const_100t.DELAY];
		util.trace( "play100t (page :"..tostring(page)..", priority: "..tostring(priority)..", delay: "..tostring(delay)..")", util.L1 );
		player100t.play( priority, pGroup , delay, delay*100, tag.MISSION_MESSAGE, page);
	end;
end;

function stop100tTimers(pGroup)
	if g100tTimerList[pGroup] ~= nil then
		for _,lTimer in ipairs(g100tTimerList[pGroup]) do
			timer.stop(lTimer);
			timer.destroy(lTimer);
		end;
		g100tTimerList[pGroup] = nil;
	end;
end;
