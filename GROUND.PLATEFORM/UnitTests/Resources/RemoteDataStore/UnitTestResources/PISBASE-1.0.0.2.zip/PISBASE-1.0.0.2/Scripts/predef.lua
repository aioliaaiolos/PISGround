--=============================================================================================
-- Description : Predefined message functions
--=============================================================================================
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 28/01/2011, A. Lafont de Sentenac
-- Corrections suite � tests sur MI09
--
-- 04/02/2011, A. Lafont de Sentenac
-- Correction CR ALPHA00216202: Contenu M�dia: L'arr�t d'un message pr�d�fini doit se faire uniquement sur les groupes concern�s par celui-ci
--	
-- 11/05/2011, P. Rival
-- Correction CR ALPHA00230672 : Messages conjoncturels: remont�e SIE
--
-- 13/05/2011, P. Rival
-- Correction CR ALPHA00230672 : Messages conjoncturels: remont�e SIE
--
-- 26/05/2011, P. Rival
-- Correction CR ALPHA00230672 : Messages conjoncturels: remont�e SIE
--
--=============================================================================================

function mUpdatePredefMessage(pCmd, pContext)
	util.trace( "mUpdatePredefMessage (pCmd: "..tostring(pCmd)..")", util.L1 );
	if pCmd == const_predef.PLAY then
		local lPriority = nil;
		local lPredefId = tostring(pContext["=SPECIAL_MESSAGE_CODE="]);
		util.trace( "mUpdatePredefMessage (lPredefId: "..lPredefId..")", util.L1 );
		local lMsgPlayed = false;
		local lGroups = mGetPredefGroups(lPredefId, gAudioGroupType);
		for _,lGroup in ipairs(lGroups) do
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.PLAY);
			mPlayAudioMessages(mGetPredefMessage(lPredefId, lGroup, gAudioGroupType, gDefaultStationAudio, pContext));
			lMsgPlayed = true;
		end;
		
		local lGroups = mGetPredefGroups(lPredefId, g100tGroupType);
		for _,lGroup in ipairs(lGroups) do
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.PLAY);
			mPlay100tMessages(mGetPredefMessage(lPredefId, lGroup, g100tGroupType, gDefaultStationName, pContext));
			lMsgPlayed = true;
		end;
		
		local lGroups = mGetPredefGroups(lPredefId, g400tGroupType);
		for _,lGroup in ipairs(lGroups) do
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.PLAY);
			mPlay400tMessages(mGetPredefMessage(lPredefId, lGroup, g400tGroupType, gDefaultStationName, pContext));
			lMsgPlayed = true;
		end;
		
		if lMsgPlayed == false then
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.PLAY_ERROR);
		end;
	elseif pCmd == const_predef.STOP then
		if dictionary.getvalue(gDictionary, variables.MESSAGE_STATUS) == const_predef.INVALID or
         dictionary.getvalue(gDictionary, variables.MESSAGE_STATUS) == const_predef.PLAY_ERROR then
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.NO_CMD);
		else
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.STOPPING);
			local lPredefId = tostring(pContext["=SPECIAL_MESSAGE_CODE="]);
			
			local lGroups = mGetPredefGroups(lPredefId, gAudioGroupType);
			for _,lGroup in ipairs(lGroups) do
				mPlayAudioMessages(mGetPredefMessage(lPredefId .. "_CLR", lGroup, gAudioGroupType, gDefaultStationAudio, pContext));
			end;
			
			local lGroups = mGetPredefGroups(lPredefId, g100tGroupType);
			for _,lGroup in ipairs(lGroups) do
				mPlay100tMessages(mGetPredefMessage(lPredefId .. "_CLR", lGroup, g100tGroupType, gDefaultStationName, pContext));
			end;
			
			local lGroups = mGetPredefGroups(lPredefId, g400tGroupType);
			for _,lGroup in ipairs(lGroups) do
				mPlay400tMessages(mGetPredefMessage(lPredefId .. "_CLR", lGroup, g400tGroupType, gDefaultStationName, pContext));
			end;
			
			dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.STOP);
		end;
	elseif pCmd == const_predef.NO_CMD then
		dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.NO_CMD);
	else
		dictionary.setvalue(gDictionary, variables.MESSAGE_STATUS, const_predef.INVALID);
	end;
end; 
