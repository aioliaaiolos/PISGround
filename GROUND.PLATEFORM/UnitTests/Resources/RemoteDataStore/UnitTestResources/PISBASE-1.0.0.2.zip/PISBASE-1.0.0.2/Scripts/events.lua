--=============================================================================================
-- Description : Events callbacks
--=============================================================================================
--
-- 04/01/2011, A. Lafont de Sentenac
-- R�organisation scripts PIS
--
-- 17/02/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00217105: Contenu media : gestion des modes
--
-- 02/03/2011, A. Lafont de Sentenac
-- Impl�mentation CR ALPHA00219578: Contenu M�dia : D�coupage des scripts en Base et Mission pour PackMaker
--
-- 04/07/2011, S. Desbat
-- Contournement CR ALPHA00239303 : 400T - Lorsqu'un afficheur 400T red�marre, il ne r�affiche pas la page en cours
--
--=============================================================================================

gLastHandledEvent = nil;
gLastHandledEventContext = nil;
gLastHandledEventStation = nil;

function mUpdateEvent(pEvent, pEventStation, pEventContext)
	util.trace( "mUpdateEvent : " .. tostring(pEvent), util.L1 );
	local context = pEventContext;
	if context == nil then
		context = mBuildContext();
	end;
	local lGroups = mGetEventGroups(pEvent, gAudioGroupType);
	for _,lGroup in ipairs(lGroups) do
		mUpdateAudio(pEvent, lGroup, pEventStation, context);
	end;
	lGroups = mGetEventGroups(pEvent, g100tGroupType);
	for _,lGroup in ipairs(lGroups) do
		mUpdate100tDisplays(pEvent, lGroup, pEventStation, context);
	end;
	lGroups = mGetEventGroups(pEvent, g400tGroupType);
	for _,lGroup in ipairs(lGroups) do
		mUpdate400tDisplays(pEvent, lGroup, pEventStation, context);
	end;
	
	if pEvent ~= gIsolationEvent then
		gLastHandledEvent = pEvent;
		gLastHandledEventContext = context;
		gLastHandledEventStation = pEventStation;
	end;
end;