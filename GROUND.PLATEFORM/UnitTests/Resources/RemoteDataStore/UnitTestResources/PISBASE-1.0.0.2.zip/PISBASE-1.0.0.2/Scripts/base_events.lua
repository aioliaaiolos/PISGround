-- Predefined message diffusion event handler
function OnPredefMessage(pName, pValue)
	util.trace( "OnPredefMessage", util.L1 );
	if gCurrentMode == const_train.ACTIVE_MODE then
      local context = mBuildContext();
		mUpdatePredefMessage(pValue, context);
	else
		util.trace( "OnPredefMessage is disabled in the current mode", util.LW );
	end;
end;

function OnCLG( pName, pValue )
	util.trace( "OnCLG", util.L1 );
	if pValue then
		if gCurrentMode == const_train.ACTIVE_MODE then
			mUpdateEvent("CLG", nil);
		else
			util.trace( "OnCLG is disabled in the current mode", util.LW );
		end;
	end;
end;

function OnWSG( pName, pValue )
	util.trace( "OnWSG", util.L1 );
	if pValue then
		if gCurrentMode == const_train.ACTIVE_MODE then
			mUpdateEvent("WSG", nil);
		else
			util.trace( "OnWSG is disabled in the current mode", util.LW );
		end;
	end;
end;

